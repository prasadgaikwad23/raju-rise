/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import { Subject } from '../types';
import {
  TrendingUp,
  Award,
  BookOpen,
  Target,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
} from 'lucide-react';

export const PerformanceView: React.FC = () => {
  const { notes, user, setActiveView } = useApp();

  const analyzed = notes.filter((n) => n.analysis);

  // Compute criteria averages
  const criteriaAvg = {
    accuracy: Math.round(
      analyzed.reduce((acc, n) => acc + (n.analysis?.criteria.contentAccuracy.score || 80), 0) /
        Math.max(1, analyzed.length)
    ),
    coverage: Math.round(
      analyzed.reduce((acc, n) => acc + (n.analysis?.criteria.topicCoverage.score || 78), 0) /
        Math.max(1, analyzed.length)
    ),
    clarity: Math.round(
      analyzed.reduce((acc, n) => acc + (n.analysis?.criteria.conceptClarity.score || 85), 0) /
        Math.max(1, analyzed.length)
    ),
    organization: Math.round(
      analyzed.reduce((acc, n) => acc + (n.analysis?.criteria.organization.score || 88), 0) /
        Math.max(1, analyzed.length)
    ),
    relevance: Math.round(
      analyzed.reduce((acc, n) => acc + (n.analysis?.criteria.examRelevance.score || 82), 0) /
        Math.max(1, analyzed.length)
    ),
  };

  const subjects: Subject[] = ['Physics', 'Chemistry', 'Mathematics', 'Biology'];

  return (
    <div className="max-w-5xl mx-auto pb-16 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          Performance &amp; Exam Readiness Analytics
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Detailed breakdown of your note-taking strengths, syllabus completeness, and exam preparedness.
        </p>
      </div>

      {/* Top Benchmark Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
          <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Exam Target</span>
          <p className="text-xl font-bold text-slate-900 dark:text-white mt-1">
            {user?.targetExam || 'JEE Main'}
          </p>
          <span className="text-[11px] text-purple-600 dark:text-purple-400 font-semibold mt-2 block">
            {user?.classLevel || 'Class 12'} · {user?.board || 'CBSE'}
          </span>
        </div>

        <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
          <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Cohort Percentile Rank</span>
          <div className="flex items-baseline gap-2 mt-1">
            <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-indigo-600">
              91.4%
            </p>
            <span className="text-xs text-emerald-600 font-semibold">Top Tier</span>
          </div>
          <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-2 block">
            Compared to 14,800+ active students
          </span>
        </div>

        <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
          <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Net Error Reduction</span>
          <div className="flex items-baseline gap-2 mt-1">
            <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400">-64%</p>
            <span className="text-xs text-slate-500">misconceptions</span>
          </div>
          <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-2 block">
            Fewer sign &amp; boundary errors in tests
          </span>
        </div>
      </div>

      {/* 5-Dimension Radar Balance */}
      <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
        <h2 className="text-base font-bold text-slate-900 dark:text-white mb-1">
          5-Criteria Academic Mastery Balance
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
          Aggregate performance across all uploaded note files against official grading weights.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {[
            { name: 'Content Accuracy', score: criteriaAvg.accuracy, weight: '30%', desc: 'Fact & formula precision' },
            { name: 'Topic Coverage', score: criteriaAvg.coverage, weight: '25%', desc: 'NCERT syllabus depth' },
            { name: 'Concept Clarity', score: criteriaAvg.clarity, weight: '15%', desc: 'Step logic & definitions' },
            { name: 'Organization', score: criteriaAvg.organization, weight: '10%', desc: 'Structure & legibility' },
            { name: 'Exam Relevance', score: criteriaAvg.relevance, weight: '20%', desc: 'Alignment with PYQs' },
          ].map((item) => (
            <div
              key={item.name}
              className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex flex-col justify-between"
            >
              <div>
                <p className="text-xs font-semibold text-slate-900 dark:text-white">{item.name}</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">{item.weight} weight</p>
                <div className="my-2">
                  <span className="text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-indigo-600">
                    {item.score}%
                  </span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-purple-600 to-indigo-500 h-full rounded-full"
                    style={{ width: `${item.score}%` }}
                  />
                </div>
              </div>
              <p className="text-[10px] text-slate-400 mt-3">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Strengths & Weaknesses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Identified Strengths */}
        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Demonstrated Note Strengths
            </h3>
          </div>
          <ul className="space-y-2.5 text-xs text-slate-700 dark:text-slate-300">
            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
              <span>Clean structural layout with clear headings and numbered lists (90%+ average).</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
              <span>Consistent inclusion of SI units and physical constants (ε₀, R, F, h).</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
              <span>Accurate naming of organic reaction reagents and catalysts.</span>
            </li>
          </ul>
        </div>

        {/* Priority Revision Areas */}
        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400">
            <AlertTriangle className="w-5 h-5" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              High-Yield Revision Priorities
            </h3>
          </div>
          <ul className="space-y-2.5 text-xs text-slate-700 dark:text-slate-300">
            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
              <span>Always state mathematical boundary conditions (e.g. closed Gaussian surfaces).</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
              <span>Differentiate scalar potentials vs vector electric/magnetic fields carefully.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
              <span>Add explicit step derivations for 3-mark CBSE / entrance exam proofs.</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
