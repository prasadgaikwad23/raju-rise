/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import {
  LayoutDashboard,
  Sparkles,
  FolderOpen,
  History,
  TrendingUp,
  Settings,
  HelpCircle,
  LogOut,
  X,
  FileCheck2,
  GraduationCap,
} from 'lucide-react';

interface SidebarProps {
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isMobileOpen, onCloseMobile }) => {
  const { user, activeView, setActiveView, logout } = useApp();

  const navigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'analyze', label: 'Analyze Notes', icon: Sparkles, highlight: true },
    { id: 'notes', label: 'My Notes', icon: FolderOpen },
    { id: 'history', label: 'Analysis History', icon: History },
    { id: 'performance', label: 'Performance', icon: TrendingUp },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'help', label: 'Help & Support', icon: HelpCircle },
  ];

  const handleSelectView = (id: string) => {
    setActiveView(id);
    onCloseMobile();
  };

  const handleLogout = () => {
    logout();
    setActiveView('landing');
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs md:hidden"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed md:sticky top-0 md:top-16 z-50 md:z-20 h-screen md:h-[calc(100vh-4rem)] w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col justify-between transition-transform duration-200 ease-in-out ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="p-4 flex flex-col h-full overflow-y-auto">
          {/* Mobile Header */}
          <div className="flex md:hidden items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white">
                <FileCheck2 className="w-4 h-4" />
              </div>
              <span className="font-bold text-slate-900 dark:text-white">NotesChecker AI</span>
            </div>
            <button
              type="button"
              onClick={onCloseMobile}
              aria-label="Close navigation sidebar"
              className="p-1.5 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Student Profile Quick Capsule */}
          {user && (
            <div className="mb-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-500 to-indigo-600 text-white flex items-center justify-center text-xs font-bold shadow-xs">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                    {user.name}
                  </p>
                  <p className="text-[11px] text-purple-600 dark:text-purple-400 font-medium truncate flex items-center gap-1">
                    <GraduationCap className="w-3 h-3" />
                    <span>{user.targetExam}</span>
                    <span className="text-slate-400">·</span>
                    <span>{user.classLevel}</span>
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Nav Links */}
          <nav className="space-y-1 flex-1" aria-label="Sidebar navigation">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id || (item.id === 'analyze' && activeView === 'results');

              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelectView(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-semibold shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
                  } ${item.highlight && !isActive ? 'text-indigo-600 dark:text-indigo-400' : ''}`}
                >
                  <Icon
                    className={`w-4 h-4 ${
                      isActive
                        ? 'text-purple-600 dark:text-purple-400'
                        : item.highlight
                        ? 'text-indigo-600 dark:text-indigo-400'
                        : 'text-slate-400 dark:text-slate-500'
                    }`}
                  />
                  <span>{item.label}</span>
                  {item.highlight && (
                    <span className="ml-auto text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300">
                      AI
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Logout at bottom */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 mt-auto">
            <button
              type="button"
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out</span>
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
