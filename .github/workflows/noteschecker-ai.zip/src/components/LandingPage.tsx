/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  FileCheck2,
  Sparkles,
  ArrowRight,
  CheckCircle,
  ScanText,
  AlertTriangle,
  BookOpen,
  Award,
  ChevronDown,
  ChevronUp,
  FileDown,
  Layers,
  GraduationCap,
  Target,
  Flame,
  Star,
  Check,
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { user, setActiveView, setAuthModalOpen, setAuthModalMode } = useApp();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleStart = () => {
    if (user) {
      setActiveView('analyze');
    } else {
      setAuthModalMode('signup');
      setAuthModalOpen(true);
    }
  };

  const handleDemo = () => {
    if (user) {
      setActiveView('dashboard');
    } else {
      setAuthModalMode('login');
      setAuthModalOpen(true);
    }
  };

  const faqs = [
    {
      q: 'Can NotesChecker AI read messy handwritten notes?',
      a: 'Yes. Our vision OCR engine is specifically trained on high school and coaching student notebook handwriting, cursive styles, rough margin diagrams, and Greek physics symbols (ε₀, λ, μ, θ, π).',
    },
    {
      q: 'Which syllabus and exams are supported?',
      a: 'We support Class 11 & Class 12 CBSE, Maharashtra State Board, ICSE/ISC, and national entrance exams including JEE Main, NEET UG, and MHT-CET across Physics, Chemistry, Biology, Mathematics, and English.',
    },
    {
      q: 'How does the 5-criteria grading algorithm work?',
      a: 'Your notes are scored out of 100 based on Content Accuracy (30%), Topic Coverage (25%), Concept Clarity (15%), Organization (10%), and Exam Relevance (20%), aligned strictly with official NCERT and exam marking schemes.',
    },
    {
      q: 'Can I download an official PDF diagnostic report?',
      a: 'Yes. Every evaluation generates a comprehensive, printable PDF report listing your score, grade, verified statements, red-flag errors, and missing NCERT derivations to paste directly into your revision binder.',
    },
    {
      q: 'Is my uploaded study material kept private?',
      a: 'Absolutely. Uploaded note pages are securely processed for academic evaluation only and remain strictly tied to your authenticated student profile.',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 md:pt-20 md:pb-28">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-gradient-to-tr from-purple-500/15 via-indigo-500/15 to-blue-500/15 blur-3xl pointer-events-none -z-10" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Target Audience Announcement */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-100/80 dark:bg-purple-950/60 border border-purple-200 dark:border-purple-800 text-xs font-medium text-purple-800 dark:text-purple-300 mb-6">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Built for Class 11 &amp; 12 · CBSE · JEE Main · NEET · MHT-CET</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white max-w-4xl mx-auto leading-tight sm:leading-none">
            Your Notes. Our AI.{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 dark:from-purple-400 dark:via-indigo-400 dark:to-blue-400">
              Better Results.
            </span>
          </h1>

          <p className="mt-6 text-lg sm:text-xl text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Upload your handwritten or digital study notes and let AI analyze, evaluate, and identify missing concepts and fatal misconceptions before exam day.
          </p>

          {/* Action CTAs */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              type="button"
              onClick={handleStart}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-semibold text-base hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-indigo-500/25 transition-all flex items-center justify-center gap-2 group"
            >
              <Sparkles className="w-4 h-4 text-purple-200 group-hover:rotate-12 transition-transform" />
              <span>Analyze My Notes</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              type="button"
              onClick={handleDemo}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 font-semibold text-base hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
            >
              <FileCheck2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>Explore Student Dashboard</span>
            </button>
          </div>

          <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
            No credit card required · Free daily OCR evaluations · Instant PDF report
          </p>

          {/* Interactive Product Preview Card */}
          <div className="mt-14 max-w-4xl mx-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl p-6 sm:p-8 text-left relative overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-100 dark:border-slate-800 gap-4">
              <div>
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1">
                  <span>Class 12 Physics</span>
                  <span>·</span>
                  <span>CBSE &amp; JEE Main Target</span>
                  <span>·</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-medium">Evaluation Complete</span>
                </div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                  Electrostatics, Coulombs Law &amp; Gauss Theorem
                </h3>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-indigo-600">
                    88<span className="text-base font-normal text-slate-400">/100</span>
                  </div>
                  <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">Grade: A (Exam Ready)</span>
                </div>
              </div>
            </div>

            {/* Criteria Preview Bars */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 my-6">
              {[
                { name: 'Accuracy', weight: '30%', score: 86, color: 'bg-emerald-500' },
                { name: 'Coverage', weight: '25%', score: 82, color: 'bg-indigo-500' },
                { name: 'Clarity', weight: '15%', score: 90, color: 'bg-purple-500' },
                { name: 'Structure', weight: '10%', score: 94, color: 'bg-blue-500' },
                { name: 'Exam PYQs', weight: '20%', score: 88, color: 'bg-violet-500' },
              ].map((c) => (
                <div key={c.name} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{c.name} ({c.weight})</p>
                  <p className="text-lg font-bold text-slate-900 dark:text-white">{c.score}%</p>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-1.5 overflow-hidden">
                    <div className={`${c.color} h-full rounded-full`} style={{ width: `${c.score}%` }} />
                  </div>
                </div>
              ))}
            </div>

            {/* Sample Error Detection Pill & Missing Concept */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200/80 dark:border-rose-900/60">
                <div className="flex items-center gap-2 text-rose-700 dark:text-rose-400 font-semibold text-xs mb-1">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Detected Error &amp; Misconception</span>
                </div>
                <p className="text-xs text-slate-800 dark:text-slate-200">
                  <span className="font-medium text-rose-600 dark:text-rose-400">Student note:</span> "Electric potential is a vector quantity."
                </p>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                  <span className="font-medium text-emerald-600 dark:text-emerald-400">AI Correction:</span> Electric potential V is scalar (work per unit charge); field E is the vector.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/60">
                <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400 font-semibold text-xs mb-1">
                  <Target className="w-4 h-4" />
                  <span>Missing NCERT Derivation</span>
                </div>
                <p className="text-xs text-slate-800 dark:text-slate-200 font-medium">
                  Field due to Infinite Plane Sheet (E = σ / 2ε₀)
                </p>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                  High-yield 3-mark CBSE question and fundamental for JEE capacitor derivations.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Complete Diagnostic Engine
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white mt-2">
              Everything you need to turn rough notebook scribbles into top marks
            </h2>
            <p className="text-slate-600 dark:text-slate-400 mt-3 text-sm sm:text-base">
              Trained on NCERT guidelines, previous 15-year entrance question papers, and official marking schemes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 hover:border-purple-300 dark:hover:border-purple-700 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center mb-5">
                <ScanText className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                Handwriting &amp; Multi-Page OCR
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Extracts cursive, hurried coaching notes, diagrams, and Greek scientific notation with high fidelity from phone photos or PDFs.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-5">
                <Award className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                5-Dimension Weighted Scoring
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Rigorous mathematical evaluation across Content Accuracy (30%), Topic Coverage (25%), Clarity (15%), Structure (10%), and Exam Relevance (20%).
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 hover:border-blue-300 dark:hover:border-blue-700 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-5">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                Conceptual Error &amp; Myth Buster
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Highlights invalid formulas, swapped signs, boundary omissions, and false generalizations with precise, verified NCERT corrections.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 hover:border-violet-300 dark:hover:border-violet-700 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-violet-100 dark:bg-violet-950/60 text-violet-600 dark:text-violet-400 flex items-center justify-center mb-5">
                <BookOpen className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                NCERT Syllabus Gap Detection
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Pinpoints high-yield topics omitted from your notebook that frequently appear in Section B, Section C, and numerical question banks.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 hover:border-emerald-300 dark:hover:border-emerald-700 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-5">
                <Target className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                Exam Readiness Diagnostic
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Custom benchmark tuned to your exact target: stricter thresholds for JEE Main / NEET vs CBSE Board examination standards.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 hover:border-pink-300 dark:hover:border-pink-700 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-pink-100 dark:bg-pink-950/60 text-pink-600 dark:text-pink-400 flex items-center justify-center mb-5">
                <FileDown className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                Instant Downloadable PDF Reports
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Generate clean, branded PDF summaries with one click to print, save in your revision folder, or share with mentors and tutors.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 border-t border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              Simple 4-Step Process
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-slate-900 dark:text-white mt-2">
              From handwritten page to complete revision roadmap in seconds
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              {
                step: '01',
                title: 'Select Exam & Board',
                desc: 'Pick Class 11 or 12, select your education board (CBSE, State Board), and target examination (JEE, NEET, MHT-CET).',
              },
              {
                step: '02',
                title: 'Upload Note Pages',
                desc: 'Drag and drop camera photos, scanned PDFs, or choose from our realistic sample notes library to test instantly.',
              },
              {
                step: '03',
                title: 'AI Vision OCR & Audit',
                desc: 'Gemini multimodal AI transcribes handwritten text and grades it against the 5 weighted academic criteria.',
              },
              {
                step: '04',
                title: 'Revise & Download PDF',
                desc: 'Inspect red-flag errors, fill in missing NCERT derivations, and download your permanent evaluation report.',
              },
            ].map((s) => (
              <div key={s.step} className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <span className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-indigo-600 dark:from-purple-400 dark:to-indigo-400">
                  {s.step}
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white mt-4 mb-2">
                  {s.title}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {s.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits for Students */}
      <section id="benefits" className="py-20 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-purple-400">
                Student Superpower
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold mt-2 leading-tight">
                Stop finding out your notes had missing concepts on exam morning
              </h2>
              <p className="text-slate-300 mt-4 text-sm leading-relaxed">
                Most students memorize notes that contain subtle boundary condition errors or lack high-weightage derivations. NotesChecker AI audits your work like an experienced senior examiner.
              </p>

              <div className="mt-8 space-y-4">
                {[
                  'Eliminate false confidence: Know exactly which subtopics you actually mastered vs skipped.',
                  'Save 50+ hours of blind revision by prioritizing identified syllabus gaps.',
                  'Master high-yield Previous Year Questions (PYQs) tied directly to note formulas.',
                  'Track improvement percentage month-over-month across Physics, Chemistry, Biology & Math.',
                ].map((b, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
                    <span className="text-sm text-slate-200">{b}</span>
                  </div>
                ))}
              </div>

              <div className="mt-8">
                <button
                  type="button"
                  onClick={handleStart}
                  className="px-6 py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-sm transition-colors flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Start Evaluating Your Notes Now</span>
                </button>
              </div>
            </div>

            {/* Visual Stats Block */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700">
                <p className="text-3xl font-extrabold text-purple-400">+18.4%</p>
                <p className="text-sm font-semibold text-white mt-1">Average Score Boost</p>
                <p className="text-xs text-slate-400 mt-2">Reported by Class 12 CBSE students within 4 weeks of note revisions.</p>
              </div>

              <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700">
                <p className="text-3xl font-extrabold text-indigo-400">94.8%</p>
                <p className="text-sm font-semibold text-white mt-1">OCR Accuracy</p>
                <p className="text-xs text-slate-400 mt-2">Even on hurried cursive notebooks and ballpoint diagram notes.</p>
              </div>

              <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700">
                <p className="text-3xl font-extrabold text-blue-400">42,000+</p>
                <p className="text-sm font-semibold text-white mt-1">Notes Checked</p>
                <p className="text-xs text-slate-400 mt-2">Across Physics, Chemistry, Mathematics, and NEET Biology.</p>
              </div>

              <div className="p-6 rounded-2xl bg-slate-800/80 border border-slate-700">
                <p className="text-3xl font-extrabold text-emerald-400">100%</p>
                <p className="text-sm font-semibold text-white mt-1">NCERT Aligned</p>
                <p className="text-xs text-slate-400 mt-2">Zero hallucinations. Strict syllabus reference checks.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 border-t border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Student Stories
            </span>
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mt-2">
              Loved by toppers and serious aspirants
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                quote:
                  'NotesChecker caught a major misconception in my Aldol condensation notes right before pre-boards. Fixed it and scored 97 in Chemistry!',
                name: 'Ananya Sharma',
                tag: 'Class 12 CBSE (96.8% Aggregate)',
                exam: 'CBSE Board 2026',
              },
              {
                quote:
                  'The syllabus gap detection for Gauss Law and Dipoles showed me the exact infinite sheet derivations I had skipped. Invaluable for JEE numericals.',
                name: 'Karthik Rao',
                tag: 'JEE Main (99.2 Percentile)',
                exam: 'JEE Main Aspirant',
              },
              {
                quote:
                  'Transcribing genetics notes and checking against NCERT Exemplar helped me secure 345/360 in NEET Biology. The PDF reports are super clean.',
                name: 'Pooja Patil',
                tag: 'NEET UG 680+ Scorer',
                exam: 'Government Medical College Admit',
              },
            ].map((t, i) => (
              <div key={i} className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col justify-between">
                <div>
                  <div className="flex gap-1 text-amber-400 mb-3">
                    {[...Array(5)].map((_, idx) => (
                      <Star key={idx} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed italic">
                    "{t.quote}"
                  </p>
                </div>
                <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800">
                  <p className="text-xs font-bold text-slate-900 dark:text-white">{t.name}</p>
                  <p className="text-[11px] text-purple-600 dark:text-purple-400">{t.tag}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-2xl mx-auto mb-14">
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Transparent Pricing
            </span>
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mt-2">
              Free for every student, with Pro superpowers
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
              Start free today and upgrade anytime for unlimited entrance exam mock analysis.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto text-left">
            {/* Free Tier */}
            <div className="p-8 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/30">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Free Student Tier</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Perfect for daily homework checking</p>
              <div className="my-6">
                <span className="text-4xl font-extrabold text-slate-900 dark:text-white">₹0</span>
                <span className="text-xs text-slate-500 dark:text-slate-400 ml-1">/ forever</span>
              </div>
              <ul className="space-y-3 text-xs text-slate-700 dark:text-slate-300 mb-8">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>5 notes evaluations per day</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Standard 5-criteria scoring</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>OCR text extraction</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Download printable PDF reports</span>
                </li>
              </ul>
              <button
                type="button"
                onClick={handleStart}
                className="w-full py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-white font-semibold text-xs hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              >
                Get Started Free
              </button>
            </div>

            {/* Pro Student Pass */}
            <div className="p-8 rounded-2xl border-2 border-purple-500 bg-gradient-to-b from-purple-50/50 to-white dark:from-purple-950/20 dark:to-slate-900 relative shadow-xl">
              <div className="absolute -top-3 right-6 px-3 py-1 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-[10px] font-bold tracking-wider uppercase">
                Most Popular
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Pro Ranker Pass</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">For serious JEE, NEET &amp; Board toppers</p>
              <div className="my-6">
                <span className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-indigo-600">₹299</span>
                <span className="text-xs text-slate-500 dark:text-slate-400 ml-1">/ month</span>
              </div>
              <ul className="space-y-3 text-xs text-slate-700 dark:text-slate-300 mb-8">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-600 shrink-0" />
                  <span><strong>Unlimited</strong> note evaluations</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-600 shrink-0" />
                  <span>Multi-page notebook batch uploads (up to 30 pages)</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-600 shrink-0" />
                  <span>15-Year PYQ high-yield question matching</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-600 shrink-0" />
                  <span>Formula revision cheat-sheets &amp; flashcards</span>
                </li>
              </ul>
              <button
                type="button"
                onClick={handleStart}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-semibold text-xs hover:from-purple-500 hover:to-indigo-500 shadow-md shadow-indigo-500/20 transition-all"
              >
                Start 7-Day Free Trial
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 border-t border-slate-200 dark:border-slate-800">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Got Questions?
            </span>
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mt-2">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden"
                >
                  <button
                    type="button"
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full text-left px-5 py-4 flex items-center justify-between text-sm font-semibold text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-purple-600 shrink-0" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-4 text-xs text-slate-600 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800/60 pt-3">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 py-12 bg-white dark:bg-slate-900 text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white">
                <FileCheck2 className="w-4 h-4" />
              </div>
              <span className="font-bold text-slate-900 dark:text-white text-sm">
                NotesChecker AI
              </span>
              <span className="text-slate-400">·</span>
              <span>Intelligent Study Notes Diagnostics</span>
            </div>

            <div className="flex items-center gap-6 text-xs">
              <a href="#features" className="hover:text-purple-600 dark:hover:text-purple-400">Features</a>
              <a href="#how-it-works" className="hover:text-purple-600 dark:hover:text-purple-400">How It Works</a>
              <a href="#pricing" className="hover:text-purple-600 dark:hover:text-purple-400">Pricing</a>
              <a href="#faq" className="hover:text-purple-600 dark:hover:text-purple-400">FAQ</a>
            </div>

            <p>© {new Date().getFullYear()} NotesChecker AI. Built for Class 11 &amp; 12 CBSE, JEE &amp; NEET aspirants.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};
