/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  ClassLevel,
  EducationBoard,
  Subject,
  ExamTarget,
  UploadedNote,
} from '../types';
import { SAMPLE_STUDENT_NOTES, SampleNoteOption } from '../data/sampleNotes';
import {
  Sparkles,
  Upload,
  FileText,
  Image as ImageIcon,
  CheckCircle,
  X,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  BookOpen,
  GraduationCap,
  Layers,
  FileCheck2,
} from 'lucide-react';

export const AnalyzeWizard: React.FC = () => {
  const { user, addNote } = useApp();

  // Wizard Steps 1 to 6
  const [step, setStep] = useState<number>(1);

  // Form selections
  const [selectedClass, setSelectedClass] = useState<ClassLevel>(
    user?.classLevel || 'Class 12'
  );
  const [selectedBoard, setSelectedBoard] = useState<EducationBoard>(
    user?.board || 'CBSE'
  );
  const [selectedSubject, setSelectedSubject] = useState<Subject>('Physics');
  const [selectedExamTarget, setSelectedExamTarget] = useState<ExamTarget>(
    user?.targetExam || 'JEE Main'
  );

  // Note title and files
  const [noteTitle, setNoteTitle] = useState<string>('Physics Electrostatics & Gauss Law');
  const [uploadedFiles, setUploadedFiles] = useState<
    Array<{ name: string; type: string; preview: string; file?: File }>
  >([]);
  const [notesText, setNotesText] = useState<string>('');
  const [selectedSample, setSelectedSample] = useState<SampleNoteOption | null>(null);

  // Analysis state & progress
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisStage, setAnalysisStage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Board options
  const boardOptions: EducationBoard[] = [
    'CBSE',
    'State Board (Maharashtra)',
    'ICSE / ISC',
    'Other State Board',
  ];

  // Subject options
  const subjectOptions: Subject[] = [
    'Physics',
    'Chemistry',
    'Mathematics',
    'Biology',
    'English',
    'Computer Science',
  ];

  // Exam Target options
  const examTargetOptions: ExamTarget[] = [
    'School Examination',
    'JEE Main',
    'NEET',
    'MHT-CET',
    'General Learning',
  ];

  // Handle file uploads
  const handleFileUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const previewUrl = e.target?.result as string;
        setUploadedFiles((prev) => [
          ...prev,
          {
            name: file.name,
            type: file.type,
            preview: previewUrl,
            file,
          },
        ]);
        if (!noteTitle) {
          setNoteTitle(file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '));
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // Select pre-loaded sample note
  const handleSelectSample = (sample: SampleNoteOption) => {
    setSelectedSample(sample);
    setSelectedClass(sample.classLevel);
    setSelectedBoard(sample.board);
    setSelectedSubject(sample.subject);
    setSelectedExamTarget(sample.examTarget);
    setNoteTitle(sample.title);
    setNotesText(sample.sampleText);
    setUploadedFiles([
      {
        name: `${sample.subject.toLowerCase()}_sample_notes.svg`,
        type: 'image/svg+xml',
        preview: sample.thumbnailSvg,
      },
    ]);
  };

  const removeUploadedFile = (index: number) => {
    setUploadedFiles((prev) => prev.filter((_, i) => i !== index));
    if (uploadedFiles.length <= 1) {
      setSelectedSample(null);
    }
  };

  // Perform Analysis
  const handleAnalyzeNotes = async () => {
    setIsAnalyzing(true);
    setErrorMessage('');

    try {
      setAnalysisStage('Extracting handwritten text using Vision OCR...');
      await new Promise((r) => setTimeout(r, 400));

      setAnalysisStage(`Verifying syllabus alignment with ${selectedBoard} & ${selectedExamTarget}...`);
      await new Promise((r) => setTimeout(r, 400));

      setAnalysisStage('Evaluating 5 academic dimensions (Accuracy 30%, Coverage 25%, Clarity 15%, Org 10%, Relevance 20%)...');
      await new Promise((r) => setTimeout(r, 400));

      setAnalysisStage('Detecting misconceptions and missing NCERT derivations...');

      const response = await fetch('/api/analyze-notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: noteTitle || `${selectedSubject} Notes`,
          classLevel: selectedClass,
          board: selectedBoard,
          subject: selectedSubject,
          examTarget: selectedExamTarget,
          images: uploadedFiles.map((f) => f.preview),
          textNotes: notesText,
        }),
      });

      if (!response.ok) {
        throw new Error(`Analysis server returned status ${response.status}`);
      }

      const data = await response.json();
      if (!data.success || !data.result) {
        throw new Error(data.error || 'Failed to complete analysis');
      }

      const newUploadedNote: UploadedNote = {
        id: `note_${Date.now()}`,
        userId: user?.id || 'guest',
        title: noteTitle || `${selectedSubject} Notes`,
        subject: selectedSubject,
        classLevel: selectedClass,
        board: selectedBoard,
        examTarget: selectedExamTarget,
        pageCount: Math.max(1, uploadedFiles.length),
        fileNames: uploadedFiles.map((f) => f.name),
        filePreviews: uploadedFiles.map((f) => f.preview),
        uploadedAt: new Date().toISOString(),
        status: 'analyzed',
        analysis: data.result,
      };

      addNote(newUploadedNote);
    } catch (err: any) {
      console.error('Error during analysis:', err);
      setErrorMessage(err.message || 'Something went wrong during notes analysis. Please try again.');
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto pb-16">
      {/* Processing Screen Overlay */}
      {isAnalyzing && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-8 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-blue-500 mx-auto flex items-center justify-center text-white shadow-xl shadow-indigo-500/30 animate-pulse mb-6">
              <Sparkles className="w-8 h-8" />
            </div>

            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              Evaluating Your Notes
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-6">
              Comparing student handwriting against official NCERT &amp; {selectedExamTarget} curriculum
            </p>

            <div className="space-y-3 text-left">
              {[
                'Transcribing handwritten/digital notes via Vision OCR',
                `Auditing ${selectedBoard} Class ${selectedClass === 'Class 11' ? '11' : '12'} syllabus coverage`,
                'Evaluating Content Accuracy (30%) & Topic Coverage (25%)',
                'Synthesizing PYQ recommendations & PDF diagnostic report',
              ].map((stage, idx) => (
                <div key={idx} className="flex items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
                  <div className="w-4 h-4 rounded-full border-2 border-purple-500 border-t-transparent animate-spin shrink-0" />
                  <span>{stage}</span>
                </div>
              ))}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800">
              <p className="text-[11px] font-medium text-purple-600 dark:text-purple-400">
                {analysisStage}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Wizard Header */}
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          Notes Analysis System
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
          Complete the 5 configuration steps, upload your notes, and let AI generate your diagnostic evaluation.
        </p>

        {/* Step Indicator */}
        <div className="grid grid-cols-5 gap-2 mt-6">
          {[
            { num: 1, title: 'Class' },
            { num: 2, title: 'Board' },
            { num: 3, title: 'Subject' },
            { num: 4, title: 'Target' },
            { num: 5, title: 'Upload' },
          ].map((s) => (
            <button
              key={s.num}
              type="button"
              onClick={() => setStep(s.num)}
              className={`p-2.5 rounded-xl border text-left transition-all ${
                step === s.num
                  ? 'border-purple-500 bg-purple-50/60 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-semibold'
                  : step > s.num
                  ? 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300'
                  : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/40 text-slate-400'
              }`}
            >
              <div className="flex items-center gap-1.5 text-xs">
                {step > s.num ? (
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                ) : (
                  <span className="w-4 h-4 rounded-full bg-slate-200 dark:bg-slate-800 text-[10px] flex items-center justify-center font-bold">
                    {s.num}
                  </span>
                )}
                <span className="truncate">{s.title}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {errorMessage && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Step 1: Select Class */}
      {step === 1 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Step 1 of 5
            </span>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              Select Your Academic Class
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              The AI aligns formula complexity and NCERT chapter scope to your level.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {(['Class 11', 'Class 12'] as ClassLevel[]).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => {
                  setSelectedClass(c);
                  setStep(2);
                }}
                className={`p-6 rounded-xl border-2 text-left transition-all flex flex-col justify-between ${
                  selectedClass === c
                    ? 'border-purple-600 bg-purple-50/50 dark:bg-purple-950/30 text-purple-900 dark:text-purple-200 shadow-md'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <span className="text-lg font-bold text-slate-900 dark:text-white">{c}</span>
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      selectedClass === c
                        ? 'border-purple-600 bg-purple-600 text-white'
                        : 'border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    {selectedClass === c && <div className="w-2 h-2 rounded-full bg-white" />}
                  </div>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {c === 'Class 11'
                    ? 'Foundational mechanics, thermodynamics, atomic structure, and organic basics.'
                    : 'Board syllabus, electrostatics, optics, organic named reactions, and calculus.'}
                </p>
              </button>
            ))}
          </div>

          <div className="flex justify-end pt-4">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="px-6 py-2.5 rounded-xl bg-purple-600 text-white font-semibold text-sm hover:bg-purple-500 transition-colors flex items-center gap-2"
            >
              <span>Next: Select Board</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Select Board */}
      {step === 2 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Step 2 of 5
            </span>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              Select Your Education Board
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Ensures marking criteria and terminology match your board's exam requirements.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {boardOptions.map((b) => (
              <button
                key={b}
                type="button"
                onClick={() => {
                  setSelectedBoard(b);
                  setStep(3);
                }}
                className={`p-5 rounded-xl border-2 text-left transition-all ${
                  selectedBoard === b
                    ? 'border-purple-600 bg-purple-50/50 dark:bg-purple-950/30 shadow-md'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-base font-bold text-slate-900 dark:text-white">{b}</span>
                  <div
                    className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      selectedBoard === b
                        ? 'border-purple-600 bg-purple-600'
                        : 'border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    {selectedBoard === b && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                  </div>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {b === 'CBSE' && 'Central Board of Secondary Education · Standard NCERT curriculum'}
                  {b === 'State Board (Maharashtra)' && 'MSBSHSE Balbharati guidelines and state entrance alignment'}
                  {b === 'ICSE / ISC' && 'Council for the Indian School Certificate Examinations'}
                  {b === 'Other State Board' && 'General state syllabus conforming to national standards'}
                </p>
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between pt-4">
            <button
              type="button"
              onClick={() => setStep(1)}
              className="px-4 py-2 text-sm text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              type="button"
              onClick={() => setStep(3)}
              className="px-6 py-2.5 rounded-xl bg-purple-600 text-white font-semibold text-sm hover:bg-purple-500 transition-colors flex items-center gap-2"
            >
              <span>Next: Select Subject</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Select Subject */}
      {step === 3 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Step 3 of 5
            </span>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              Select Your Subject
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Select the subject corresponding to the notes you are uploading.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
            {subjectOptions.map((subj) => (
              <button
                key={subj}
                type="button"
                onClick={() => {
                  setSelectedSubject(subj);
                  setStep(4);
                }}
                className={`p-4 rounded-xl border-2 text-left transition-all ${
                  selectedSubject === subj
                    ? 'border-purple-600 bg-purple-50/50 dark:bg-purple-950/30 shadow-md'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-bold text-slate-900 dark:text-white">{subj}</span>
                  <div
                    className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      selectedSubject === subj
                        ? 'border-purple-600 bg-purple-600'
                        : 'border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    {selectedSubject === subj && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                  </div>
                </div>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  {subj === 'Physics' && 'Derivations & numericals'}
                  {subj === 'Chemistry' && 'Reactions & physical laws'}
                  {subj === 'Mathematics' && 'Theorems & step proofs'}
                  {subj === 'Biology' && 'NCERT diagrams & terms'}
                  {subj === 'English' && 'Literature & grammar'}
                  {subj === 'Computer Science' && 'Python & algorithms'}
                </span>
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between pt-4">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="px-4 py-2 text-sm text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              type="button"
              onClick={() => setStep(4)}
              className="px-6 py-2.5 rounded-xl bg-purple-600 text-white font-semibold text-sm hover:bg-purple-500 transition-colors flex items-center gap-2"
            >
              <span>Next: Select Exam Target</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 4: Select Exam Target */}
      {step === 4 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Step 4 of 5
            </span>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              Select Your Target Examination
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Competitive exams (JEE / NEET) apply stricter accuracy and high-yield PYQ weighting.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {examTargetOptions.map((target) => (
              <button
                key={target}
                type="button"
                onClick={() => {
                  setSelectedExamTarget(target);
                  setStep(5);
                }}
                className={`p-4 rounded-xl border-2 text-left transition-all ${
                  selectedExamTarget === target
                    ? 'border-purple-600 bg-purple-50/50 dark:bg-purple-950/30 shadow-md'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-base font-bold text-slate-900 dark:text-white">{target}</span>
                  <div
                    className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      selectedExamTarget === target
                        ? 'border-purple-600 bg-purple-600'
                        : 'border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    {selectedExamTarget === target && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                  </div>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {target === 'School Examination' && 'Focus on subjective step marks, definitions, and theory derivations.'}
                  {target === 'JEE Main' && 'Stricter rigor: advanced concepts, edge cases, and numerical shortcuts.'}
                  {target === 'NEET' && 'NCERT line-by-line factual adherence and diagrammatic accuracy.'}
                  {target === 'MHT-CET' && 'Maharashtra state textbook syllabus and high-speed formula recall.'}
                  {target === 'General Learning' && 'Overall conceptual clarity and logical organization.'}
                </p>
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between pt-4">
            <button
              type="button"
              onClick={() => setStep(3)}
              className="px-4 py-2 text-sm text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              type="button"
              onClick={() => setStep(5)}
              className="px-6 py-2.5 rounded-xl bg-purple-600 text-white font-semibold text-sm hover:bg-purple-500 transition-colors flex items-center gap-2"
            >
              <span>Next: Upload Notes</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 5 & 6: Upload Notes and Analyze Button */}
      {step === 5 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              Step 5 of 5
            </span>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              Upload Your Study Notes
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Supports multiple photos of handwritten notebooks, PDF files, JPG or PNG scans.
            </p>
          </div>

          {/* Quick Note Title input */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Note Topic / Title
            </label>
            <input
              type="text"
              value={noteTitle}
              onChange={(e) => setNoteTitle(e.target.value)}
              placeholder="e.g. Electrostatics & Gauss Law Notes"
              className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>

          {/* Drag & Drop Upload Zone */}
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              handleFileUpload(e.dataTransfer.files);
            }}
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-purple-500 dark:hover:border-purple-400 rounded-2xl p-8 text-center cursor-pointer bg-slate-50/50 dark:bg-slate-800/30 transition-colors"
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={(e) => handleFileUpload(e.target.files)}
              accept="image/*,application/pdf"
              multiple
              className="hidden"
            />
            <div className="w-12 h-12 rounded-xl bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 mx-auto flex items-center justify-center mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <p className="text-sm font-semibold text-slate-900 dark:text-white">
              Drag and drop note pages here, or browse files
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Supports PDF, PNG, JPG (Multi-page handwritten notes supported)
            </p>
          </div>

          {/* Sample Notes Quick Select (for immediate 1-click test) */}
          <div className="pt-2">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                <span>Or Pick a Realistic Sample Student Note to Test Instantly:</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {SAMPLE_STUDENT_NOTES.map((sample) => (
                <button
                  key={sample.id}
                  type="button"
                  onClick={() => handleSelectSample(sample)}
                  className={`p-3 rounded-xl border text-left text-xs transition-all flex items-start gap-3 ${
                    selectedSample?.id === sample.id
                      ? 'border-indigo-500 bg-indigo-50/60 dark:bg-indigo-950/40 text-indigo-950 dark:text-indigo-200 font-medium'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/40 hover:border-slate-300'
                  }`}
                >
                  <div className="w-10 h-14 bg-white dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700 shrink-0 overflow-hidden">
                    <img src={sample.thumbnailSvg} alt={sample.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-slate-900 dark:text-white truncate">{sample.title}</p>
                    <p className="text-[11px] text-purple-600 dark:text-purple-400 font-semibold">{sample.subject} · {sample.examTarget}</p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">{sample.description}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Uploaded File Previews */}
          {uploadedFiles.length > 0 && (
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white mb-2">
                Attached Note Pages ({uploadedFiles.length})
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {uploadedFiles.map((file, idx) => (
                  <div
                    key={idx}
                    className="relative group rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 aspect-3/4 flex flex-col items-center justify-center p-2"
                  >
                    {file.preview ? (
                      <img
                        src={file.preview}
                        alt={file.name}
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <FileText className="w-8 h-8 text-slate-400" />
                    )}
                    <button
                      type="button"
                      onClick={() => removeUploadedFile(idx)}
                      className="absolute top-1 right-1 p-1 rounded-full bg-slate-900/70 text-white hover:bg-rose-600 transition-colors"
                      aria-label="Remove page"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                    <span className="absolute bottom-1 left-1 right-1 text-[9px] bg-slate-900/80 text-white px-1 py-0.5 rounded truncate text-center">
                      Page {idx + 1}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Optional Direct Note Text Input / Transcription Note */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300">
                Notes Transcript / Additional Scribbles (Optional)
              </label>
              <span className="text-[10px] text-slate-400">
                Used alongside Vision OCR for enhanced accuracy
              </span>
            </div>
            <textarea
              rows={3}
              value={notesText}
              onChange={(e) => setNotesText(e.target.value)}
              placeholder="Paste or type handwritten equations, formulas, or rough notes here..."
              className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>

          {/* Step 6: Prominent Analyze Button */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <button
              type="button"
              onClick={() => setStep(4)}
              className="px-4 py-2 text-sm text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white flex items-center gap-1.5 self-start sm:self-auto"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            <button
              type="button"
              onClick={handleAnalyzeNotes}
              disabled={uploadedFiles.length === 0 && !notesText.trim()}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-500/30 transition-all flex items-center justify-center gap-2.5 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            >
              <Sparkles className="w-5 h-5 text-purple-200" />
              <span>Analyze My Notes</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
