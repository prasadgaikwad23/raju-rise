/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import { Subject, UploadedNote } from '../types';
import {
  Sparkles,
  TrendingUp,
  FileCheck2,
  Award,
  ChevronRight,
  ArrowUpRight,
  Clock,
  BookOpen,
  FolderOpen,
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const { user, notes, setActiveView, setCurrentAnalysis } = useApp();

  const totalNotes = notes.length;
  const analyzedNotes = notes.filter((n) => n.analysis);
  const avgScore =
    analyzedNotes.length > 0
      ? Math.round(
          analyzedNotes.reduce((acc, curr) => acc + (curr.analysis?.overallScore || 0), 0) /
            analyzedNotes.length
        )
      : 0;

  // Subject-wise stats
  const subjects: Subject[] = ['Physics', 'Chemistry', 'Mathematics', 'Biology'];
  const subjectStats = subjects.map((subj) => {
    const subjNotes = notes.filter((n) => n.subject === subj && n.analysis);
    const score =
      subjNotes.length > 0
        ? Math.round(
            subjNotes.reduce((sum, n) => sum + (n.analysis?.overallScore || 0), 0) /
              subjNotes.length
          )
        : null;
    return {
      subject: subj,
      count: subjNotes.length,
      averageScore: score,
    };
  });

  const handleOpenNote = (note: UploadedNote) => {
    if (note.analysis) {
      setCurrentAnalysis(note.analysis);
      setActiveView('results');
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white p-6 sm:p-8 shadow-xl">
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs text-purple-300 font-medium mb-1.5">
              <span>{user?.classLevel || 'Class 12'}</span>
              <span>·</span>
              <span>{user?.board || 'CBSE'}</span>
              <span>·</span>
              <span className="text-emerald-400 font-semibold">{user?.targetExam || 'JEE Main'} Target</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
              Welcome back, {user?.name || 'Scholar'}! 👋
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-xl">
              Your overall notes quality is up <span className="text-emerald-400 font-semibold">+18%</span> this month. Keep verifying high-yield NCERT derivations to ace your examination.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setActiveView('analyze')}
            className="self-start sm:self-auto px-5 py-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-semibold text-sm shadow-md shadow-purple-500/30 transition-all flex items-center gap-2 shrink-0 group"
          >
            <Sparkles className="w-4 h-4 text-purple-200 group-hover:rotate-12 transition-transform" />
            <span>Analyze New Notes</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Notes */}
        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Notes Analyzed</span>
            <div className="p-2 rounded-lg bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400">
              <FileCheck2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{totalNotes}</span>
            <span className="text-xs text-slate-500">documents</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            Active in current term
          </p>
        </div>

        {/* Average Notes Score */}
        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Average Notes Score</span>
            <div className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">{avgScore || 85}</span>
            <span className="text-xs text-slate-500">/ 100</span>
          </div>
          <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium mt-2">
            Top 12% in Class 12 CBSE cohort
          </p>
        </div>

        {/* Improvement Percentage */}
        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Overall Improvement</span>
            <div className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">+18.2%</span>
            <span className="text-xs text-slate-500">since sign up</span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            Reduced error rate by 64%
          </p>
        </div>

        {/* Exam Readiness */}
        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Exam Readiness</span>
            <div className="p-2 rounded-lg bg-violet-50 dark:bg-violet-950/50 text-violet-600 dark:text-violet-400">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white">
              {notes[0]?.analysis?.examReadinessPercentage || 82}%
            </span>
            <span className="text-xs text-purple-600 dark:text-purple-400 font-medium">
              {user?.targetExam || 'JEE'}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            Ready for mock test simulation
          </p>
        </div>
      </div>

      {/* Subject-Wise Performance Grid */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">Subject-Wise Performance</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Diagnostic scores across core {user?.classLevel || 'Class 12'} subjects
            </p>
          </div>
          <button
            type="button"
            onClick={() => setActiveView('performance')}
            className="text-xs font-medium text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1"
          >
            <span>Full Analytics</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {subjectStats.map((item) => {
            const hasData = item.averageScore !== null;
            const score = item.averageScore || 0;
            return (
              <div
                key={item.subject}
                className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-slate-900 dark:text-white">
                      {item.subject}
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      {item.count} {item.count === 1 ? 'note' : 'notes'}
                    </span>
                  </div>

                  {hasData ? (
                    <>
                      <div className="flex items-baseline gap-1 my-1">
                        <span className="text-xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-indigo-600">
                          {score}
                        </span>
                        <span className="text-xs text-slate-400">/ 100</span>
                      </div>
                      <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-purple-500 to-indigo-500 h-full rounded-full"
                          style={{ width: `${score}%` }}
                        />
                      </div>
                    </>
                  ) : (
                    <div className="py-3">
                      <p className="text-xs text-slate-400 italic">No notes uploaded yet</p>
                      <button
                        type="button"
                        onClick={() => setActiveView('analyze')}
                        className="text-[11px] text-purple-600 dark:text-purple-400 font-semibold hover:underline mt-1 block"
                      >
                        + Check {item.subject}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Analysis History Table */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">Recent Notes Analysis</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Click any note to view full diagnostic breakdown or download PDF report
            </p>
          </div>
          <button
            type="button"
            onClick={() => setActiveView('notes')}
            className="text-xs font-medium text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1"
          >
            <span>View All ({notes.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {notes.length === 0 ? (
          <div className="py-12 text-center">
            <FolderOpen className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              No notes evaluated yet
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-4">
              Upload your handwritten or digital study notes to see AI evaluation
            </p>
            <button
              type="button"
              onClick={() => setActiveView('analyze')}
              className="px-4 py-2 rounded-lg bg-purple-600 text-white text-xs font-semibold hover:bg-purple-500 transition-colors"
            >
              Analyze Your First Note
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {notes.slice(0, 5).map((note) => {
              const analysis = note.analysis;
              const dateStr = new Date(note.uploadedAt).toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
              });

              return (
                <div
                  key={note.id}
                  onClick={() => handleOpenNote(note)}
                  className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/40 px-2 rounded-xl transition-colors cursor-pointer group"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-12 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center shrink-0 overflow-hidden">
                      {note.filePreviews[0] ? (
                        <img
                          src={note.filePreviews[0]}
                          alt={note.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <FileCheck2 className="w-5 h-5 text-slate-400" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                        {note.title}
                      </h4>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        <span className="font-medium text-indigo-600 dark:text-indigo-400">{note.subject}</span>
                        <span>·</span>
                        <span>{note.classLevel}</span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {dateStr}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 self-end sm:self-auto">
                    {analysis && (
                      <div className="text-right">
                        <span className="text-base font-extrabold text-slate-900 dark:text-white">
                          {analysis.overallScore}
                          <span className="text-xs font-normal text-slate-400">/100</span>
                        </span>
                        <span className="text-[10px] block text-emerald-600 dark:text-emerald-400 font-semibold">
                          Grade {analysis.grade}
                        </span>
                      </div>
                    )}

                    <div className="p-1 text-slate-400 group-hover:text-purple-600 group-hover:translate-x-0.5 transition-all">
                      <ChevronRight className="w-5 h-5" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
