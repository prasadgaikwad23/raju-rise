/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  HelpCircle,
  Camera,
  Sun,
  FileCheck2,
  CheckCircle2,
  Send,
  MessageSquare,
  BookOpen,
} from 'lucide-react';

export const HelpSupportView: React.FC = () => {
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setTicketSubject('');
      setTicketMessage('');
      setSubmitted(false);
    }, 3000);
  };

  return (
    <div className="max-w-4xl mx-auto pb-16 space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          Help &amp; Academic Support
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Learn how to get the most accurate OCR evaluations and understand exam syllabus grading.
        </p>
      </div>

      {/* Guide: How to photograph handwritten notes */}
      <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
          <Camera className="w-5 h-5 text-purple-600 dark:text-purple-400" />
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            Best Practices for Photographing Handwritten Notes
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 space-y-2">
            <Sun className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-slate-900 dark:text-white">1. Bright Even Lighting</h3>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
              Ensure natural sunlight or a desk lamp illuminates your notebook evenly without creating hand or phone shadows across formulas.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 space-y-2">
            <Camera className="w-5 h-5 text-indigo-500" />
            <h3 className="font-bold text-slate-900 dark:text-white">2. Hold Camera Flat</h3>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
              Capture the notebook page parallel to the surface to eliminate perspective tilt and distortion on subscripts, superscripts, and fractions.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 space-y-2">
            <FileCheck2 className="w-5 h-5 text-emerald-500" />
            <h3 className="font-bold text-slate-900 dark:text-white">3. Clear Contrast</h3>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
              Blue or black ink on unruled or ruled white paper yields optimal OCR transcription, especially for Greek symbols (ε, λ, ρ, θ).
            </p>
          </div>
        </div>
      </div>

      {/* Support Ticket / Academic Question Form */}
      <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
          <MessageSquare className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            Ask an Academic Mentor or Report an OCR Question
          </h2>
        </div>

        {submitted ? (
          <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-center">
            <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto mb-1" />
            <p className="text-xs font-bold text-emerald-800 dark:text-emerald-300">
              Query Received!
            </p>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-0.5">
              Our academic mentoring team will review your question within 24 hours.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Subject / Query Title
              </label>
              <input
                type="text"
                required
                value={ticketSubject}
                onChange={(e) => setTicketSubject(e.target.value)}
                placeholder="e.g. Discrepancy in Gauss Law Derivation Step"
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Message / Question Details
              </label>
              <textarea
                required
                rows={4}
                value={ticketMessage}
                onChange={(e) => setTicketMessage(e.target.value)}
                placeholder="Describe what concept you are struggling with or how we can assist..."
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition-colors flex items-center gap-2 shadow-sm"
              >
                <Send className="w-4 h-4" />
                <span>Submit Query</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
