/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { useApp } from '../context/AppContext';
import { generatePdfReport } from '../utils/pdfExport';
import {
  Award,
  AlertTriangle,
  Target,
  CheckCircle2,
  FileDown,
  RefreshCw,
  PlusCircle,
  Save,
  BookOpen,
  ArrowRight,
  TrendingUp,
  FileText,
  Lightbulb,
  Check,
} from 'lucide-react';

export const AnalysisResultsView: React.FC = () => {
  const { currentAnalysis, user, setActiveView } = useApp();
  const [activeTab, setActiveTab] = useState<
    'errors' | 'missing' | 'formulas' | 'verified' | 'recommendations' | 'ocr'
  >('errors');
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    if (currentAnalysis && currentAnalysis.overallScore >= 80) {
      try {
        confetti({
          particleCount: 70,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#7c3aed', '#6366f1', '#3b82f6', '#10b981'],
        });
      } catch (e) {
        // Safe fallback if window or canvas is restricted
      }
    }
  }, [currentAnalysis?.id]);

  if (!currentAnalysis) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center">
        <BookOpen className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">
          No Analysis Selected
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-6">
          Upload a handwritten note or select one from your notes library to view diagnostics.
        </p>
        <button
          type="button"
          onClick={() => setActiveView('analyze')}
          className="px-6 py-2.5 rounded-xl bg-purple-600 text-white font-semibold text-xs hover:bg-purple-500 transition-colors"
        >
          Analyze Notes Now
        </button>
      </div>
    );
  }

  const {
    overallScore,
    grade,
    examReadinessPercentage,
    criteria,
    title,
    subject,
    classLevel,
    board,
    examTarget,
    detectedErrors,
    missingConcepts,
    importantFormulas,
    correctConcepts,
    recommendations,
    ocrExtractedText,
    summary,
  } = currentAnalysis;

  const handleDownloadPdf = () => {
    generatePdfReport(currentAnalysis, user);
  };

  const handleSave = () => {
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  // Color mappings based on score
  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-emerald-500 stroke-emerald-500';
    if (score >= 70) return 'text-purple-600 stroke-purple-600';
    if (score >= 50) return 'text-amber-500 stroke-amber-500';
    return 'text-rose-500 stroke-rose-500';
  };

  // SVG Circular Gauge calculations
  const radius = 64;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (overallScore / 100) * circumference;

  return (
    <div className="max-w-5xl mx-auto pb-16 space-y-6">
      {/* Top Banner & Action Buttons */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span className="font-semibold text-purple-600 dark:text-purple-400">{subject}</span>
            <span>·</span>
            <span>{classLevel}</span>
            <span>·</span>
            <span>{board}</span>
            <span>·</span>
            <span className="font-medium text-indigo-600 dark:text-indigo-400">{examTarget}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            {title}
          </h1>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleDownloadPdf}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow-sm shadow-purple-500/20 transition-all flex items-center gap-1.5"
          >
            <FileDown className="w-4 h-4" />
            <span>Download PDF Report</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            {isSaved ? <Check className="w-4 h-4 text-emerald-500" /> : <Save className="w-4 h-4" />}
            <span>{isSaved ? 'Saved!' : 'Save Analysis'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('analyze')}
            className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Re-analyze</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('analyze')}
            className="px-3.5 py-2 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50/60 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Analyze Another Subject</span>
          </button>
        </div>
      </div>

      {/* Main Score & Readiness Hero Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Score Gauge Card */}
        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs flex flex-col items-center justify-center text-center">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
            Overall Notes Score
          </p>

          <div className="relative w-40 h-40 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
              <circle
                cx="80"
                cy="80"
                r={radius}
                className="stroke-slate-100 dark:stroke-slate-800"
                strokeWidth="12"
                fill="none"
              />
              <circle
                cx="80"
                cy="80"
                r={radius}
                className={`transition-all duration-1000 ease-out ${getScoreColor(overallScore)}`}
                strokeWidth="12"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="none"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-4xl font-black text-slate-900 dark:text-white">
                {overallScore}
              </span>
              <span className="text-xs font-semibold text-slate-400">OUT OF 100</span>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <span className="text-xs text-slate-500">Grade:</span>
            <span className="text-sm font-bold px-2.5 py-0.5 rounded-full bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300">
              {grade}
            </span>
          </div>
        </div>

        {/* Exam Readiness & Performance Indices */}
        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs flex flex-col justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">
              Exam Target Benchmark
            </p>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              {examTarget} Readiness
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Evaluated against previous 10-year question patterns and marking schemes.
            </p>
          </div>

          <div className="my-4">
            <div className="flex items-baseline justify-between mb-1.5">
              <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-indigo-600">
                {examReadinessPercentage}%
              </span>
              <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                {examReadinessPercentage >= 75 ? 'Exam Ready' : 'Needs Reinforcement'}
              </span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-purple-600 to-indigo-500 h-full rounded-full transition-all duration-1000"
                style={{ width: `${examReadinessPercentage}%` }}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs pt-3 border-t border-slate-100 dark:border-slate-800">
            <div>
              <span className="text-slate-400 text-[11px] block">Accuracy</span>
              <span className="font-bold text-slate-900 dark:text-white">
                {criteria.contentAccuracy.score}%
              </span>
            </div>
            <div>
              <span className="text-slate-400 text-[11px] block">NCERT Coverage</span>
              <span className="font-bold text-slate-900 dark:text-white">
                {criteria.topicCoverage.score}%
              </span>
            </div>
          </div>
        </div>

        {/* Executive Evaluator Summary */}
        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-2">
              <Award className="w-4 h-4" />
              <span>Senior Academic Evaluation</span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
              {summary}
            </p>
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Errors Identified:</span>
              <span className="font-bold text-rose-600 dark:text-rose-400">
                {detectedErrors.length} {detectedErrors.length === 1 ? 'error' : 'errors'}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs mt-1.5">
              <span className="text-slate-500">Missing NCERT Topics:</span>
              <span className="font-bold text-amber-600 dark:text-amber-400">
                {missingConcepts.length} subtopics
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 5-Criteria Progress Bars */}
      <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
          Detailed Criteria Dimension Breakdown
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
          Weighted strictly according to academic guidelines: Content Accuracy (30%), Topic Coverage (25%), Concept Clarity (15%), Organization (10%), Exam Relevance (20%).
        </p>

        <div className="space-y-4">
          {[
            criteria.contentAccuracy,
            criteria.topicCoverage,
            criteria.conceptClarity,
            criteria.organization,
            criteria.examRelevance,
          ].map((c) => (
            <div key={c.name} className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {c.name}{' '}
                  <span className="text-slate-400 font-normal">({c.weight}% weight)</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {c.score}/100{' '}
                  <span className="text-purple-600 dark:text-purple-400 font-semibold text-[11px]">
                    ({c.weightedScore} pts)
                  </span>
                </span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-purple-500 via-indigo-500 to-blue-500 h-full rounded-full transition-all duration-700"
                  style={{ width: `${c.score}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 italic">
                {c.feedback}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Tabs for Diagnostic Findings */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs overflow-hidden">
        {/* Tab Headers */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 overflow-x-auto bg-slate-50/50 dark:bg-slate-800/20 px-4 pt-2">
          {[
            { id: 'errors', label: `Detected Errors (${detectedErrors.length})`, icon: AlertTriangle, color: 'text-rose-500' },
            { id: 'missing', label: `Missing Topics (${missingConcepts.length})`, icon: Target, color: 'text-amber-500' },
            { id: 'formulas', label: `Formulas (${importantFormulas.length})`, icon: BookOpen, color: 'text-indigo-500' },
            { id: 'verified', label: `Correct Points (${correctConcepts.length})`, icon: CheckCircle2, color: 'text-emerald-500' },
            { id: 'recommendations', label: `AI Next Steps (${recommendations.length})`, icon: Lightbulb, color: 'text-purple-500' },
            { id: 'ocr', label: 'OCR Transcript', icon: FileText, color: 'text-slate-500' },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
                  isActive
                    ? 'border-purple-600 text-purple-700 dark:text-purple-300 bg-white dark:bg-slate-900'
                    : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-purple-600' : tab.color}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Contents */}
        <div className="p-6">
          {/* Detected Errors */}
          {activeTab === 'errors' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Identified Misconceptions &amp; Incorrect Statements
                </h4>
                <span className="text-xs text-rose-600 dark:text-rose-400 font-medium">
                  Review these before exam day
                </span>
              </div>

              {detectedErrors.length === 0 ? (
                <p className="text-xs text-emerald-600 dark:text-emerald-400 py-4">
                  No factual inaccuracies or conceptual errors found! Great job.
                </p>
              ) : (
                detectedErrors.map((err, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/50 dark:bg-rose-950/20 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-rose-800 dark:text-rose-300">
                        {idx + 1}. {err.topic}
                      </span>
                      <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-rose-100 dark:bg-rose-900/60 text-rose-700 dark:text-rose-300">
                        {err.severity} impact
                      </span>
                    </div>

                    <div className="text-xs space-y-1">
                      <p className="text-slate-700 dark:text-slate-300">
                        <span className="font-semibold text-rose-600 dark:text-rose-400">
                          Student notes statement:
                        </span>{' '}
                        "{err.studentText}"
                      </p>
                      <p className="text-slate-600 dark:text-slate-400">
                        <span className="font-medium text-slate-500">Why it's wrong:</span>{' '}
                        {err.issue}
                      </p>
                      <p className="text-slate-800 dark:text-slate-200 pt-1 font-medium">
                        <span className="font-bold text-emerald-600 dark:text-emerald-400">
                          Verified Correction:
                        </span>{' '}
                        {err.correction}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Missing Concepts */}
          {activeTab === 'missing' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Missing NCERT Syllabus Topics &amp; High-Yield Derivations
                </h4>
                <span className="text-xs text-amber-600 dark:text-amber-400 font-medium">
                  Frequently tested in {examTarget}
                </span>
              </div>

              {missingConcepts.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/50 dark:bg-amber-950/20 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-800 dark:text-amber-300">
                      {idx + 1}. {item.topic}
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300">
                      {item.importance}
                    </span>
                  </div>

                  <p className="text-xs text-slate-700 dark:text-slate-300">
                    {item.summary}
                  </p>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                    <span>
                      <strong>Why it matters:</strong> {item.examRelevance}
                    </span>
                    <span className="text-purple-600 dark:text-purple-400 font-medium">
                      {item.syllabusReference}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Formulas */}
          {activeTab === 'formulas' && (
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-2">
                Essential Exam Formulas Cheatsheet
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {importantFormulas.map((f, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900 dark:text-white">
                        {f.name}
                      </span>
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                          f.notesStatus === 'correct'
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                            : f.notesStatus === 'inaccurate'
                            ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300'
                            : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                        }`}
                      >
                        In Notes: {f.notesStatus}
                      </span>
                    </div>
                    <p className="font-mono text-xs font-semibold text-purple-700 dark:text-purple-300 bg-white dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-700">
                      {f.formula}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {f.whereUsed}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Verified Correct Points */}
          {activeTab === 'verified' && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-2">
                What You Got Right (Verified Concepts)
              </h4>

              {correctConcepts.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/40 dark:bg-emerald-950/20 flex items-start gap-2.5 text-xs text-slate-800 dark:text-slate-200"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          )}

          {/* Recommendations */}
          {activeTab === 'recommendations' && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-2">
                Actionable AI Revision Plan for {examTarget}
              </h4>

              {recommendations.map((rec, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl border border-indigo-200 dark:border-indigo-900/60 bg-indigo-50/40 dark:bg-indigo-950/20 flex items-start gap-3 text-xs text-slate-800 dark:text-slate-200"
                >
                  <div className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0">
                    {idx + 1}
                  </div>
                  <div>
                    <p className="font-medium">{rec}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* OCR Transcript */}
          {activeTab === 'ocr' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between mb-1">
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Handwriting OCR Transcription
                </h4>
                <span className="text-[11px] text-slate-400">
                  Transcribed by Vision OCR Engine
                </span>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-mono text-xs text-slate-800 dark:text-slate-300 whitespace-pre-wrap leading-relaxed max-h-96 overflow-y-auto">
                {ocrExtractedText || 'No OCR transcript available.'}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
