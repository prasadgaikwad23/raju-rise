/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UploadedNote, AnalysisResult } from '../types';
import { SAMPLE_STUDENT_NOTES } from '../data/sampleNotes';
import { calculateWeightedScore, calculateGrade, calculateExamReadiness } from '../utils/scoring';

interface AppContextType {
  user: UserProfile | null;
  darkMode: boolean;
  toggleDarkMode: () => void;
  login: (email: string, name?: string) => void;
  loginAsDemo: () => void;
  logout: () => void;
  updateProfile: (updated: Partial<UserProfile>) => void;
  notes: UploadedNote[];
  addNote: (note: UploadedNote) => void;
  deleteNote: (id: string) => void;
  currentAnalysis: AnalysisResult | null;
  setCurrentAnalysis: (analysis: AnalysisResult | null) => void;
  activeView: string;
  setActiveView: (view: string) => void;
  isAuthModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  authModalMode: 'login' | 'signup' | 'forgot';
  setAuthModalMode: (mode: 'login' | 'signup' | 'forgot') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEFAULT_DEMO_USER: UserProfile = {
  id: 'usr_rahul_12',
  name: 'Rahul Sharma',
  email: 'rahul.sharma@student.edu',
  targetExam: 'JEE Main',
  classLevel: 'Class 12',
  board: 'CBSE',
  institution: 'Delhi Public School, R.K. Puram',
  joinedAt: '2026-08-15',
};

const INITIAL_DEMO_NOTES: UploadedNote[] = [
  {
    id: 'note_demo_1',
    userId: 'usr_rahul_12',
    title: 'Electrostatics & Coulombs Law Notes',
    subject: 'Physics',
    classLevel: 'Class 12',
    board: 'CBSE',
    examTarget: 'JEE Main',
    pageCount: 3,
    fileNames: ['physics_electrostatics_pg1.jpg', 'physics_electrostatics_pg2.jpg'],
    filePreviews: [SAMPLE_STUDENT_NOTES[0].thumbnailSvg],
    uploadedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    status: 'analyzed',
    analysis: {
      id: 'eval_demo_1',
      noteId: 'note_demo_1',
      title: 'Electrostatics & Coulombs Law Notes',
      subject: 'Physics',
      classLevel: 'Class 12',
      board: 'CBSE',
      examTarget: 'JEE Main',
      createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      overallScore: 82,
      grade: 'A',
      examReadinessPercentage: 78,
      criteria: calculateWeightedScore({
        contentAccuracy: 84,
        topicCoverage: 78,
        conceptClarity: 86,
        organization: 90,
        examRelevance: 80,
      }).criteria,
      ocrExtractedText: SAMPLE_STUDENT_NOTES[0].sampleText,
      correctConcepts: [
        'Coulomb Law stated with vacuum permittivity constant (8.854 × 10^-12 C²/N·m²).',
        'Electric dipole moment vector direction accurately identified from -q to +q.',
        'Inverse cube (1/r³) distance relation for dipole field correctly derived.',
      ],
      detectedErrors: [
        {
          topic: 'Electric Potential',
          studentText: 'Potential is a vector quantity with direction towards lower field.',
          issue: 'Electric potential is a scalar quantity derived from work done per unit charge.',
          correction: 'Electric field is the vector; electric potential V is scalar (V = -∫ E·dr).',
          severity: 'high',
        },
        {
          topic: 'Gauss Law Conditions',
          studentText: 'Gauss theorem applies to any surface containing charges.',
          issue: 'Omission of the term "closed surface" (Gaussian surface).',
          correction: 'Gauss Law applies strictly to a CLOSED 3D surface enclosing charge (Φ = ∮ E·dA = q_enc / ε₀).',
          severity: 'medium',
        },
      ],
      missingConcepts: [
        {
          topic: 'Electric Field of Infinite Thin Plane Sheet',
          importance: 'Critical for Exam',
          examRelevance: 'Recurring 3-mark derivation in CBSE Boards and baseline for parallel-plate capacitors in JEE.',
          syllabusReference: 'NCERT Physics Part 1, Chapter 1, Section 1.15.2',
          summary: 'Derive E = σ / (2ε₀) using a cylindrical Gaussian pillbox perpendicular to the sheet.',
        },
        {
          topic: 'Work Done in Rotating Dipole in Uniform Field',
          importance: 'High Weightage',
          examRelevance: 'Common JEE Main numerical problem on potential energy changes W = pE(cos θ₁ - cos θ₂).',
          syllabusReference: 'NCERT Section 1.12',
          summary: 'Explicitly state the reference zero potential energy configuration (at θ = 90°).',
        },
      ],
      importantFormulas: [
        {
          name: 'Coulombs Force',
          formula: 'F = (1 / 4πε₀) * (q₁q₂ / r²)',
          whereUsed: 'Point charge electrostatic interactions',
          notesStatus: 'correct',
        },
        {
          name: 'Gauss Law Flux',
          formula: 'Φ = ∮ E · dA = q_enc / ε₀',
          whereUsed: 'Symmetric charge distributions (cylinders, spheres, planes)',
          notesStatus: 'inaccurate',
        },
        {
          name: 'Infinite Wire Field',
          formula: 'E = λ / (2πε₀r)',
          whereUsed: 'Linear charge distribution calculations',
          notesStatus: 'correct',
        },
      ],
      recommendations: [
        'Add the missing Gauss Law derivation for an infinite sheet (E = σ/2ε₀) with a labeled diagram.',
        'Clarify the scalar nature of electric potential V to avoid sign errors in multi-charge questions.',
        'Solve 5 Previous Year JEE Main questions on torque on dipoles in non-uniform fields.',
        'Create a dedicated SI units and dimensions reference column for pre-exam revision.',
      ],
      keyTopicsIdentified: ['Coulomb Law', 'Electric Dipole', 'Gauss Theorem', 'Gaussian Cylinder'],
      summary: 'Solid foundational notes with clean handwriting. The core theorems are well-structured, but addressing the scalar potential confusion and adding the infinite sheet derivation will elevate this note to 95+ score.',
    },
  },
  {
    id: 'note_demo_2',
    userId: 'usr_rahul_12',
    title: 'Aldehydes, Ketones & Named Reactions',
    subject: 'Chemistry',
    classLevel: 'Class 12',
    board: 'CBSE',
    examTarget: 'JEE Main',
    pageCount: 2,
    fileNames: ['chem_aldehydes_pg1.jpg'],
    filePreviews: [SAMPLE_STUDENT_NOTES[1].thumbnailSvg],
    uploadedAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    status: 'analyzed',
    analysis: {
      id: 'eval_demo_2',
      noteId: 'note_demo_2',
      title: 'Aldehydes, Ketones & Named Reactions',
      subject: 'Chemistry',
      classLevel: 'Class 12',
      board: 'CBSE',
      examTarget: 'JEE Main',
      createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
      overallScore: 88,
      grade: 'A',
      examReadinessPercentage: 84,
      criteria: calculateWeightedScore({
        contentAccuracy: 88,
        topicCoverage: 84,
        conceptClarity: 90,
        organization: 92,
        examRelevance: 88,
      }).criteria,
      ocrExtractedText: SAMPLE_STUDENT_NOTES[1].sampleText,
      correctConcepts: [
        'Aldol condensation mechanism with dilute NaOH and heating to form enals.',
        'Rosenmund reduction catalyst poisoned with BaSO4 correctly specified.',
        'Tollens reagent silver mirror reaction equations accurately written.',
      ],
      detectedErrors: [
        {
          topic: 'Cannizzaro Reaction Substrates',
          studentText: 'Acetaldehyde undergoes Cannizzaro reaction with concentrated alkali.',
          issue: 'Acetaldehyde (CH3CHO) contains 3 alpha-hydrogens, so it undergoes Aldol condensation instead.',
          correction: 'Cannizzaro requires aldehydes with NO alpha-hydrogens (e.g. Formaldehyde, Benzaldehyde).',
          severity: 'high',
        },
      ],
      missingConcepts: [
        {
          topic: 'Clemmensen & Wolff-Kishner Reductions',
          importance: 'Critical for Exam',
          examRelevance: 'Guaranteed 4 marks in JEE Main organic conversions.',
          syllabusReference: 'NCERT Chemistry Part 2, Chapter 12',
          summary: 'Clemmensen uses Zn-Hg/conc. HCl (acid sensitive); Wolff-Kishner uses NH2-NH2/KOH/ethylene glycol (base sensitive).',
        },
      ],
      importantFormulas: [
        {
          name: 'Aldol Condensation',
          formula: '2 R-CH₂-CHO → R-CH₂-CH=C(R)-CHO + H₂O',
          whereUsed: 'Carbon-carbon bond formation',
          notesStatus: 'correct',
        },
      ],
      recommendations: [
        'Differentiate between acid-sensitive and base-sensitive carbonyl reduction methods in your table.',
        'Highlight the alpha-hydrogen prerequisite for Aldol vs Cannizzaro.',
      ],
      keyTopicsIdentified: ['Nucleophilic Addition', 'Aldol', 'Cannizzaro', 'Tollens Test'],
      summary: 'High-quality organic reaction summary with accurate structures. Clear demarcation between aldehyde and ketone tests.',
    },
  },
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Dark mode state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('noteschecker_dark');
    return saved ? JSON.parse(saved) : false;
  });

  // User state
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('noteschecker_user');
    return saved ? JSON.parse(saved) : DEFAULT_DEMO_USER;
  });

  // Notes state
  const [notes, setNotes] = useState<UploadedNote[]>(() => {
    const saved = localStorage.getItem('noteschecker_notes');
    return saved ? JSON.parse(saved) : INITIAL_DEMO_NOTES;
  });

  // Active view in dashboard: 'dashboard' | 'analyze' | 'notes' | 'history' | 'performance' | 'settings' | 'help' | 'results'
  const [activeView, setActiveView] = useState<string>('dashboard');
  const [currentAnalysis, setCurrentAnalysis] = useState<AnalysisResult | null>(
    INITIAL_DEMO_NOTES[0].analysis || null
  );

  // Auth modal
  const [isAuthModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup' | 'forgot'>('login');

  useEffect(() => {
    localStorage.setItem('noteschecker_dark', JSON.stringify(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('noteschecker_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('noteschecker_user');
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('noteschecker_notes', JSON.stringify(notes));
  }, [notes]);

  const toggleDarkMode = () => setDarkMode((prev) => !prev);

  const login = (email: string, name?: string) => {
    const newUser: UserProfile = {
      id: `usr_${Date.now()}`,
      name: name || email.split('@')[0],
      email,
      targetExam: 'JEE Main',
      classLevel: 'Class 12',
      board: 'CBSE',
      joinedAt: new Date().toISOString().split('T')[0],
    };
    setUser(newUser);
    setAuthModalOpen(false);
  };

  const loginAsDemo = () => {
    setUser(DEFAULT_DEMO_USER);
    setAuthModalOpen(false);
  };

  const logout = () => {
    setUser(null);
  };

  const updateProfile = (updated: Partial<UserProfile>) => {
    setUser((prev) => (prev ? { ...prev, ...updated } : null));
  };

  const addNote = (note: UploadedNote) => {
    setNotes((prev) => [note, ...prev]);
    if (note.analysis) {
      setCurrentAnalysis(note.analysis);
      setActiveView('results');
    }
  };

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    if (currentAnalysis && currentAnalysis.noteId === id) {
      setCurrentAnalysis(null);
    }
  };

  return (
    <AppContext.Provider
      value={{
        user,
        darkMode,
        toggleDarkMode,
        login,
        loginAsDemo,
        logout,
        updateProfile,
        notes,
        addNote,
        deleteNote,
        currentAnalysis,
        setCurrentAnalysis,
        activeView,
        setActiveView,
        isAuthModalOpen,
        setAuthModalOpen,
        authModalMode,
        setAuthModalMode,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
