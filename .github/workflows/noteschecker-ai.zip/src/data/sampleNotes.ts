/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Subject, ClassLevel, EducationBoard, ExamTarget } from '../types';

export interface SampleNoteOption {
  id: string;
  title: string;
  subject: Subject;
  classLevel: ClassLevel;
  board: EducationBoard;
  examTarget: ExamTarget;
  description: string;
  pageCount: number;
  sampleText: string;
  thumbnailSvg: string; // SVG data uri for visual notes preview
}

export const SAMPLE_STUDENT_NOTES: SampleNoteOption[] = [
  {
    id: 'sample-physics-electrostatics',
    title: 'Electrostatics, Coulombs Law & Gauss Law Notes',
    subject: 'Physics',
    classLevel: 'Class 12',
    board: 'CBSE',
    examTarget: 'JEE Main',
    description: 'Handwritten classroom notes covering Electric Charges, Dipole, and Gauss Law with 2 minor conceptual gaps.',
    pageCount: 3,
    sampleText: `CHAPTER 1: ELECTRIC CHARGES AND FIELDS
• Coulomb's Law:
F = (1 / 4πε₀) * (q₁ * q₂ / r²)
where ε₀ = 8.854 * 10^-12 C²/N·m²
In vector form: F₁₂ = -F₂₁ (obeys Newton's 3rd Law)

• Electric Dipole:
Dipole moment p = q * (2a), directed from -q to +q.
Electric field at axial point: E_axial = (1 / 4πε₀) * (2p / r³) [for r >> a]
Electric field at equatorial point: E_equatorial = (1 / 4πε₀) * (p / r³)

• Gauss Theorem:
Flux Φ = E * A = q / ε₀
Used to find electric field of infinite wire: E = λ / (2πε₀r).
Also field inside conductor is zero.
Field outside conducting sphere: E = Q / (4πε₀r²).

• Potential Energy of Dipole:
U = -p · E = -p E cos(θ)
Torque τ = p × E = p E sin(θ)

Student notes note: Did not write whether Gauss surface must be closed or symmetrical.
Did not derive electric field due to infinite thin plane sheet (E = σ / 2ε₀).
Wrote potential is a vector quantity in margin notes.`,
    thumbnailSvg: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="400" viewBox="0 0 300 400" fill="%23fdfbf7"><rect width="300" height="400" fill="%23f8fafc" rx="8"/><line x1="45" y1="0" x2="45" y2="400" stroke="%23fda4af" stroke-width="1.5"/><line x1="0" y1="60" x2="300" y2="60" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="90" x2="300" y2="90" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="120" x2="300" y2="120" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="150" x2="300" y2="150" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="180" x2="300" y2="180" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="210" x2="300" y2="210" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="240" x2="300" y2="240" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="270" x2="300" y2="270" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="300" x2="300" y2="300" stroke="%23e2e8f0" stroke-width="1"/><text x="55" y="52" font-family="sans-serif" font-size="13" font-weight="bold" fill="%231e293b">Ch 1: Electric Charges &amp; Fields</text><text x="55" y="82" font-family="monospace" font-size="10" fill="%23334155">F = (1/4πε₀) · (q₁q₂ / r²)</text><text x="55" y="112" font-family="sans-serif" font-size="10" fill="%23334155">Dipole p = q · (2a) [-q to +q]</text><text x="55" y="142" font-family="monospace" font-size="10" fill="%23334155">E_axial = (1/4πε₀)·(2p/r³)</text><text x="55" y="172" font-family="sans-serif" font-size="10" fill="%23334155">Gauss Law: Φ = ∮ E·dA = q/ε₀</text><text x="55" y="202" font-family="sans-serif" font-size="9" fill="%2364748b">• Infinite wire: E = λ/(2πε₀r)</text><text x="55" y="232" font-family="sans-serif" font-size="9" fill="%2364748b">• τ = p × E, U = -p · E</text><circle cx="210" cy="270" r="18" fill="none" stroke="%236366f1" stroke-width="1.5"/><line x1="210" y1="270" x2="225" y2="260" stroke="%236366f1" stroke-width="1.5"/><text x="180" y="315" font-family="sans-serif" font-size="8" fill="%236366f1">Gaussian Cylinder</text></svg>`,
  },
  {
    id: 'sample-chem-aldehydes',
    title: 'Aldehydes, Ketones & Named Organic Reactions',
    subject: 'Chemistry',
    classLevel: 'Class 12',
    board: 'CBSE',
    examTarget: 'NEET',
    description: 'Organic chemistry reactions sheet featuring Aldol, Cannizzaro, Tollens test, and Wolff-Kishner reduction.',
    pageCount: 2,
    sampleText: `ORGANIC CHEMISTRY - ALDEHYDES & KETONES
1. Preparation:
- Rosenmund Reduction: Acyl chloride + H₂ with Pd/BaSO₄ gives Aldehyde.
- Stephen reaction: Nitriles with SnCl₂ + HCl followed by H₃O⁺.

2. Nucleophilic Addition:
Carbonyl carbon is sp² hybridized, attacked by nucleophile.
Reactivity order: HCHO > CH₃CHO > CH₃COCH₃ (due to steric hindrance and +I effect of alkyl groups).

3. Important Named Reactions:
- Aldol Condensation: Requires α-hydrogen.
2 CH₃CHO + dil NaOH → CH₃-CH(OH)-CH₂-CHO (3-hydroxybutanal) → heated → CH₃-CH=CH-CHO (But-2-enal).
- Cannizzaro Reaction: Compounds lacking α-H.
Formaldehyde + 50% KOH → Methanol + Potassium formate (self redox).
Note in student margin: Wrote acetaldehyde gives Cannizzaro reaction.
- Tollens Test: Silver mirror test. Aldehydes reduce Tollens reagent [Ag(NH₃)₂]⁺ to metallic silver.
- Fehling Test: Gives red precipitate of Cu₂O with aliphatic aldehydes.
Missing: Clemmensen reduction (Zn-Hg / conc HCl) and Hell-Volhard-Zelinsky (HVZ) reaction for carboxylic acids.`,
    thumbnailSvg: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="400" viewBox="0 0 300 400" fill="%23fdfbf7"><rect width="300" height="400" fill="%23f8fafc" rx="8"/><line x1="45" y1="0" x2="45" y2="400" stroke="%23fda4af" stroke-width="1.5"/><line x1="0" y1="60" x2="300" y2="60" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="90" x2="300" y2="90" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="120" x2="300" y2="120" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="150" x2="300" y2="150" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="180" x2="300" y2="180" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="210" x2="300" y2="210" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="240" x2="300" y2="240" stroke="%23e2e8f0" stroke-width="1"/><text x="55" y="52" font-family="sans-serif" font-size="13" font-weight="bold" fill="%230f172a">Organic Reactions: Carbonyls</text><text x="55" y="82" font-family="sans-serif" font-size="10" fill="%23334155">1. Rosenmund: RCOCl + H₂/Pd-BaSO₄ → RCHO</text><text x="55" y="112" font-family="sans-serif" font-size="10" fill="%23334155">2. Aldol (α-H): 2 CH₃CHO → But-2-enal</text><text x="55" y="142" font-family="sans-serif" font-size="10" fill="%23334155">3. Cannizzaro: 2 HCHO + KOH → CH₃OH + HCOOK</text><text x="55" y="172" font-family="sans-serif" font-size="10" fill="%23334155">4. Tollens Test: Ag mirror with [Ag(NH₃)₂]⁺</text><text x="55" y="202" font-family="sans-serif" font-size="9" fill="%2364748b">Fehling solution gives red Cu₂O ppt</text></svg>`,
  },
  {
    id: 'sample-bio-genetics',
    title: 'Principles of Inheritance & Mendelian Genetics',
    subject: 'Biology',
    classLevel: 'Class 12',
    board: 'CBSE',
    examTarget: 'NEET',
    description: 'Class 12 NCERT Biology notes covering Mendel laws, Punnett square, pedigree, and chromosomal disorders.',
    pageCount: 3,
    sampleText: `NCERT BIOLOGY: PRINCIPLES OF INHERITANCE
• Gregor Johann Mendel conducted hybridization experiments on garden pea (Pisum sativum) for 7 years (1856-1863).
• 7 pairs of contrasting traits (Seed shape, Seed color, Flower color, Pod shape, Pod color, Flower position, Stem height).

• Mendel's Laws:
1. Law of Dominance: Characters controlled by discrete units called factors (genes). Factors occur in pairs.
2. Law of Segregation: Alleles do not show blending; both characters recovered in F2 generation. Gametes receive only one allele.
3. Law of Independent Assortment: Applies to dihybrid cross (F2 phenotypic ratio 9:3:3:1).

• Non-Mendelian Inheritance:
- Incomplete Dominance: Mirabilis jalapa (4 O'clock plant) and Antirrhinum (snapdragon). F2 phenotypic and genotypic ratio = 1:2:1 (Red : Pink : White).
- Co-dominance: ABO blood grouping governed by gene I (alleles I^A, I^B, i).

• Genetic Disorders:
- Thalassemia: Quantitative blood problem (reduced synthesis of globin chains).
- Student note says: Sickle cell anemia is sex-linked recessive disorder.
- Down's Syndrome: Trisomy of chromosome 21 (Langdon Down, 1866). 47 chromosomes.
Missing: Morgan's linkage & recombination experiment on Drosophila melanogaster, Turner's syndrome (45, XO) & Klinefelter's syndrome (47, XXY).`,
    thumbnailSvg: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="400" viewBox="0 0 300 400" fill="%23fdfbf7"><rect width="300" height="400" fill="%23f8fafc" rx="8"/><line x1="45" y1="0" x2="45" y2="400" stroke="%23fda4af" stroke-width="1.5"/><line x1="0" y1="60" x2="300" y2="60" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="90" x2="300" y2="90" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="120" x2="300" y2="120" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="150" x2="300" y2="150" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="180" x2="300" y2="180" stroke="%23e2e8f0" stroke-width="1"/><text x="55" y="52" font-family="sans-serif" font-size="13" font-weight="bold" fill="%23065f46">Ch 5: Principles of Inheritance</text><text x="55" y="82" font-family="sans-serif" font-size="10" fill="%23334155">Mendel 7 traits in Pisum sativum</text><text x="55" y="112" font-family="sans-serif" font-size="10" fill="%23334155">Monohybrid F2: 3:1 (Pheno), 1:2:1 (Geno)</text><text x="55" y="142" font-family="sans-serif" font-size="10" fill="%23334155">Incomplete Dominance: 1:2:1 (Snapdragon)</text><text x="55" y="172" font-family="sans-serif" font-size="10" fill="%23334155">Down's: Trisomy 21 (47, XX / XY)</text></svg>`,
  },
  {
    id: 'sample-math-calculus',
    title: 'Definite Integrals & Linear Differential Equations',
    subject: 'Mathematics',
    classLevel: 'Class 12',
    board: 'State Board (Maharashtra)',
    examTarget: 'MHT-CET',
    description: 'High-speed formula cheat-sheet with integration properties and linear differential equations shortcuts.',
    pageCount: 2,
    sampleText: `MATHEMATICS: INTEGRALS & DIFFERENTIAL EQUATIONS
• Standard Integrals:
∫ 1/(x² + a²) dx = (1/a) tan⁻¹(x/a) + C
∫ 1/√(a² - x²) dx = sin⁻¹(x/a) + C
∫ 1/(x² - a²) dx = (1/2a) ln|(x - a)/(x + a)| + C

• King Property of Definite Integrals:
∫₀ᵃ f(x) dx = ∫₀ᵃ f(a - x) dx
Very useful for: ∫₀^(π/2) sinⁿ(x) / (sinⁿ(x) + cosⁿ(x)) dx = π/4

• Integration by Parts:
∫ u · v dx = u ∫ v dx - ∫ [u' · (∫ v dx)] dx (ILATE rule: Inverse, Log, Algebraic, Trig, Exponential).

• First Order Linear Differential Equation:
dy/dx + P(x) y = Q(x)
Integrating Factor (I.F.) = e^(∫ P dx)
Solution: y · (I.F.) = ∫ [Q · (I.F.)] dx + C

Student note error: Stated degree of (d²y/dx² + sin(dy/dx) = 0) is 2. (Incorrect: degree is not defined!).
Missing: Homogeneous differential equation substitution y = vx.`,
    thumbnailSvg: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="400" viewBox="0 0 300 400" fill="%23fdfbf7"><rect width="300" height="400" fill="%23f8fafc" rx="8"/><line x1="45" y1="0" x2="45" y2="400" stroke="%23fda4af" stroke-width="1.5"/><line x1="0" y1="60" x2="300" y2="60" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="90" x2="300" y2="90" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="120" x2="300" y2="120" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="150" x2="300" y2="150" stroke="%23e2e8f0" stroke-width="1"/><line x1="0" y1="180" x2="300" y2="180" stroke="%23e2e8f0" stroke-width="1"/><text x="55" y="52" font-family="sans-serif" font-size="13" font-weight="bold" fill="%231e1b4b">Calculus: Integrals &amp; D.E.</text><text x="55" y="82" font-family="monospace" font-size="10" fill="%23334155">∫ 1/(x²+a²) dx = (1/a) arctan(x/a)</text><text x="55" y="112" font-family="monospace" font-size="10" fill="%23334155">∫₀ᵃ f(x) dx = ∫₀ᵃ f(a-x) dx [King]</text><text x="55" y="142" font-family="monospace" font-size="10" fill="%23334155">dy/dx + Py = Q → I.F. = e^(∫P dx)</text><text x="55" y="172" font-family="sans-serif" font-size="10" fill="%23334155">Soln: y·(I.F.) = ∫ Q·(I.F.) dx + C</text></svg>`,
  },
];
