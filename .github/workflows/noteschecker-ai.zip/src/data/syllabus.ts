/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Subject, ClassLevel, ExamTarget } from '../types';

export interface TopicExpectation {
  topic: string;
  mustHaveFormulas: string[];
  keyDefinitions: string[];
  commonMisconceptions: {
    studentMistake: string;
    correction: string;
  }[];
  highYieldPYQAreas: string[];
}

export const SYLLABUS_DATABASE: Record<string, TopicExpectation[]> = {
  'Physics_Class 12': [
    {
      topic: 'Electrostatics & Electric Charges',
      mustHaveFormulas: [
        'F = (1 / 4πε₀) * (q₁q₂ / r²)',
        'E = F / q₀ = (1 / 4πε₀) * (q / r²)',
        'Φ_E = ∮ E · dA = q_enc / ε₀ (Gauss Law)',
        'V = (1 / 4πε₀) * (q / r)',
        'U = (1 / 4πε₀) * (q₁q₂ / r)',
      ],
      keyDefinitions: [
        'Electric field intensity at an axial and equatorial point of a dipole',
        'Gauss Theorem and its Gaussian surface symmetry conditions',
        'Equipotential surfaces and their properties (no work done)',
        'Dielectric polarization and capacitance with dielectric slab',
      ],
      commonMisconceptions: [
        {
          studentMistake: 'Writing Gauss law without mentioning closed surface or permittivity of medium',
          correction: 'Gauss Law states total electric flux through any CLOSED surface is 1/ε₀ times net enclosed charge.',
        },
        {
          studentMistake: 'Assuming electric field inside a non-conducting charged sphere is zero',
          correction: 'Electric field is zero inside a CONDUCTOR in electrostatic equilibrium, but inside a uniformly charged dielectric sphere E = (ρ * r) / (3ε₀).',
        },
        {
          studentMistake: 'Treating electric potential as a vector quantity',
          correction: 'Electric potential is a scalar quantity, whereas electric field intensity is a vector.',
        },
      ],
      highYieldPYQAreas: [
        'Gauss Law derivation for infinite line charge and infinite plane sheet',
        'Torque and potential energy of electric dipole in uniform field',
        'Capacitance of parallel plate capacitor with variable dielectric constants',
      ],
    },
    {
      topic: 'Current Electricity & Circuits',
      mustHaveFormulas: [
        'I = n·A·e·v_d (Drift velocity relation)',
        'R = ρ·L / A = m / (n·e²·τ) * (L / A)',
        'V = E - I·r (Terminal voltage)',
        'Kirchhoff Junction: Σ I = 0, Loop: Σ ΔV = 0',
        'Wheatstone Bridge balance: P / Q = R / S',
      ],
      keyDefinitions: [
        'Ohm Law microscopic form: J = σ·E',
        'Temperature coefficient of resistance (α)',
        'Electromotive force (EMF) vs Potential difference',
      ],
      commonMisconceptions: [
        {
          studentMistake: 'Equating EMF to terminal voltage under non-zero current',
          correction: 'Terminal voltage V = E - Ir during discharge; V is less than EMF due to internal resistance drop.',
        },
      ],
      highYieldPYQAreas: ['Kirchhoff circuit laws mesh analysis', 'Combination of cells in parallel with unequal EMFs'],
    },
    {
      topic: 'Electromagnetic Induction & AC',
      mustHaveFormulas: [
        'ε = -dΦ/dt (Faraday-Lenz Law)',
        'ε = B·l·v (Motional EMF)',
        'L = μ₀·n²·A·l (Self inductance of solenoid)',
        'Z = √[R² + (X_L - X_C)²]',
        'f_r = 1 / (2π√(LC)) (Resonance frequency)',
      ],
      keyDefinitions: [
        'Lenz Law as a consequence of Law of Conservation of Energy',
        'Mutual induction and coefficient of coupling',
        'Power factor cos(φ) in series LCR circuit and Wattless current',
      ],
      commonMisconceptions: [
        {
          studentMistake: 'Omitting minus sign in Faraday law, forgetting Lenz law opposition',
          correction: 'The negative sign ε = -N(dΦ/dt) represents Lenz Law: induced EMF opposes the change in flux.',
        },
      ],
      highYieldPYQAreas: ['LCR resonance curve and Quality factor Q', 'Transformer efficiency and eddy current losses'],
    },
  ],
  'Chemistry_Class 12': [
    {
      topic: 'Aldehydes, Ketones and Carboxylic Acids',
      mustHaveFormulas: [
        'Rosenmund Reduction: RCOCl + H₂ (Pd/BaSO₄) → RCHO',
        'Aldol Condensation: 2 CH₃CHO (dil. NaOH) → CH₃-CH(OH)-CH₂-CHO',
        'Cannizzaro Reaction: 2 HCHO (conc. KOH) → HCOOK + CH₃OH',
        'Tollens Test: RCHO + 2[Ag(NH₃)₂]⁺ + 3OH⁻ → RCOO⁻ + 2Ag↓ + 4NH₃ + 2H₂O',
      ],
      keyDefinitions: [
        'Nucleophilic addition mechanism on carbonyl carbon',
        'Alpha-hydrogen acidity in aldehydes and ketones',
        'Fehling and Tollens reagent differentiating aldehydes from ketones',
      ],
      commonMisconceptions: [
        {
          studentMistake: 'Claiming ketones give positive Tollens silver mirror test',
          correction: 'Only aldehydes give positive Tollens test (except alpha-hydroxy ketones); regular ketones do not oxidize easily.',
        },
        {
          studentMistake: 'Applying Cannizzaro reaction to acetaldehyde',
          correction: 'Acetaldehyde has alpha-hydrogens, so it undergoes Aldol condensation, NOT Cannizzaro. Cannizzaro requires NO alpha-hydrogens (e.g. Benzaldehyde, Formaldehyde).',
        },
      ],
      highYieldPYQAreas: ['Cross-aldol products prediction', 'Clemmensen vs Wolff-Kishner reduction conditions'],
    },
    {
      topic: 'Electrochemistry & Chemical Kinetics',
      mustHaveFormulas: [
        'E_cell = E°_cell - (0.0591 / n) * log(Q) (Nernst Equation at 298K)',
        'ΔG° = -n * F * E°_cell',
        'Λ_m = (κ * 1000) / M',
        'k = A * e^(-E_a / RT) (Arrhenius Equation)',
        't_(1/2) = 0.693 / k (First order half-life)',
      ],
      keyDefinitions: [
        'Kohlrausch Law of Independent Migration of Ions',
        'Molecularity vs Order of reaction',
        'Activation energy and pseudo-first order kinetics',
      ],
      commonMisconceptions: [
        {
          studentMistake: 'Thinking order of reaction can be derived strictly from balanced stoichiometric coefficients',
          correction: 'Order of reaction is an experimental quantity and cannot be deduced purely from overall reaction equation.',
        },
      ],
      highYieldPYQAreas: ['Nernst equation calculations on concentration cells', 'Arrhenius plot slope (-Ea/2.303R)'],
    },
  ],
  'Biology_Class 12': [
    {
      topic: 'Genetics and Principles of Inheritance',
      mustHaveFormulas: [
        'Monohybrid F2 phenotypic ratio: 3:1, genotypic ratio: 1:2:1',
        'Dihybrid F2 phenotypic ratio: 9:3:3:1',
        'Hardy-Weinberg equilibrium: p² + 2pq + q² = 1',
      ],
      keyDefinitions: [
        'Mendel Law of Segregation and Law of Independent Assortment',
        'Incomplete dominance (Mirabilis jalapa) and Co-dominance (ABO blood groups)',
        'Sex-linked recessive disorders: Hemophilia, Color blindness, Thalassemia vs Sickle Cell Anemia',
      ],
      commonMisconceptions: [
        {
          studentMistake: 'Stating that Sickle Cell Anemia is a sex-linked recessive disorder',
          correction: 'Sickle cell anemia is an AUTOSOMAL recessive disorder caused by GAG to GUG point mutation in beta-globin chain (glutamic acid to valine).',
        },
      ],
      highYieldPYQAreas: ['Pedigree chart analysis rules', 'Chromosomal aberrations: Down, Turner, Klinefelter syndromes'],
    },
  ],
  'Mathematics_Class 12': [
    {
      topic: 'Calculus: Integrals & Differential Equations',
      mustHaveFormulas: [
        '∫ (1 / (x² + a²)) dx = (1/a) * arctan(x/a) + C',
        'Integration by Parts: ∫ u·v dx = u·∫v dx - ∫(u\'·∫v dx)dx',
        'Definite integral property: ∫₀ᵃ f(x) dx = ∫₀ᵃ f(a - x) dx (King property)',
        'Linear Differential Equation: dy/dx + P(x)·y = Q(x) → I.F. = e^(∫P dx)',
      ],
      keyDefinitions: [
        'Fundamental Theorem of Calculus',
        'Order and degree of differential equations',
        'Area bounded between curves by vertical / horizontal slicing',
      ],
      commonMisconceptions: [
        {
          studentMistake: 'Assuming degree exists for any differential equation containing sin(dy/dx) or e^(dy/dx)',
          correction: 'Degree is defined only when the differential equation is a polynomial in its derivatives.',
        },
      ],
      highYieldPYQAreas: ['Definite integral King property problems', 'Integrating Factor linear differential equations'],
    },
  ],
};
