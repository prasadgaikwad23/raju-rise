/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { jsPDF } from 'jspdf';
import { AnalysisResult, UserProfile } from '../types';

export function generatePdfReport(analysis: AnalysisResult, user?: UserProfile | null) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 18;

  // Header banner background
  doc.setFillColor(30, 27, 75); // Deep Indigo (#1e1b4b)
  doc.rect(0, 0, pageWidth, 28, 'F');

  // Title
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('NotesChecker AI', 14, 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(224, 231, 255);
  doc.text('Intelligent Notes Evaluation & Exam Readiness Diagnostic Report', 14, 18);

  doc.setFontSize(8);
  doc.setTextColor(199, 210, 254);
  doc.text(`Generated: ${new Date().toLocaleDateString('en-US', { dateStyle: 'long' })}`, pageWidth - 14, 18, {
    align: 'right',
  });

  y = 38;

  // Document metadata box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, y, pageWidth - 28, 22, 2, 2, 'FD');

  doc.setTextColor(51, 65, 85);
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.text('DOCUMENT:', 18, y + 6);
  doc.setFont('helvetica', 'normal');
  doc.text(analysis.title, 40, y + 6);

  doc.setFont('helvetica', 'bold');
  doc.text('SUBJECT:', 18, y + 12);
  doc.setFont('helvetica', 'normal');
  doc.text(`${analysis.subject} (${analysis.classLevel} · ${analysis.board})`, 40, y + 12);

  doc.setFont('helvetica', 'bold');
  doc.text('TARGET EXAM:', 18, y + 18);
  doc.setFont('helvetica', 'normal');
  doc.text(analysis.examTarget, 40, y + 18);

  if (user) {
    doc.setFont('helvetica', 'bold');
    doc.text('STUDENT:', pageWidth - 80, y + 6);
    doc.setFont('helvetica', 'normal');
    doc.text(user.name, pageWidth - 55, y + 6);
  }

  y += 28;

  // Overall Score & Grade Banner
  doc.setFillColor(243, 232, 255); // Purple tint
  doc.setDrawColor(192, 132, 252);
  doc.roundedRect(14, y, pageWidth - 28, 22, 2, 2, 'FD');

  doc.setTextColor(107, 33, 168);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text(`Overall Notes Score: ${analysis.overallScore}/100`, 20, y + 9);

  doc.setFontSize(9.5);
  doc.setTextColor(75, 85, 99);
  doc.setFont('helvetica', 'normal');
  doc.text(
    `Performance Grade: ${analysis.grade}   |   Exam Readiness: ${analysis.examReadinessPercentage}% for ${analysis.examTarget}`,
    20,
    y + 16
  );

  y += 28;

  // Criteria Table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(30, 41, 59);
  doc.text('EVALUATION CRITERIA BREAKDOWN', 14, y);
  y += 5;

  const criteriaList = [
    analysis.criteria.contentAccuracy,
    analysis.criteria.topicCoverage,
    analysis.criteria.conceptClarity,
    analysis.criteria.organization,
    analysis.criteria.examRelevance,
  ];

  doc.setFillColor(241, 245, 249);
  doc.rect(14, y, pageWidth - 28, 6, 'F');
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('Criteria Dimension', 18, y + 4.2);
  doc.text('Weight', 80, y + 4.2);
  doc.text('Score', 105, y + 4.2);
  doc.text('Weighted Points', 130, y + 4.2);
  doc.text('Evaluator Remarks', 160, y + 4.2);
  y += 7;

  criteriaList.forEach((c) => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(30, 41, 59);
    doc.text(c.name, 18, y + 4);
    doc.text(`${c.weight}%`, 80, y + 4);
    doc.text(`${c.score}/100`, 105, y + 4);
    doc.text(`${c.weightedScore} pts`, 130, y + 4);

    const remarksLines = doc.splitTextToSize(c.feedback, 36);
    doc.text(remarksLines[0] || '', 160, y + 4);

    doc.setDrawColor(241, 245, 249);
    doc.line(14, y + 6, pageWidth - 14, y + 6);
    y += 7;
  });

  y += 6;

  // Detected Errors & Corrections
  if (analysis.detectedErrors && analysis.detectedErrors.length > 0) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(185, 28, 28); // Red
    doc.text('DETECTED CONCEPTUAL MISCONCEPTIONS & CORRECTIONS', 14, y);
    y += 5;

    analysis.detectedErrors.slice(0, 3).forEach((err, idx) => {
      doc.setFillColor(254, 242, 242);
      doc.setDrawColor(254, 202, 202);
      doc.roundedRect(14, y, pageWidth - 28, 14, 1.5, 1.5, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(153, 27, 27);
      doc.text(`${idx + 1}. Issue in ${err.topic}: ${err.studentText}`, 18, y + 4.5);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(30, 41, 59);
      doc.text(`Correction: ${err.correction}`, 18, y + 9.5);

      y += 16;
    });
  }

  y += 4;

  // Missing Topics & High Yield PYQ
  if (analysis.missingConcepts && analysis.missingConcepts.length > 0) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(217, 119, 6); // Amber
    doc.text('MISSING HIGH-YIELD TOPICS (NCERT & EXAM SYLLABUS GAPS)', 14, y);
    y += 5;

    analysis.missingConcepts.slice(0, 2).forEach((miss, idx) => {
      doc.setFillColor(255, 251, 235);
      doc.setDrawColor(253, 230, 138);
      doc.roundedRect(14, y, pageWidth - 28, 12, 1.5, 1.5, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(146, 64, 14);
      doc.text(`${idx + 1}. ${miss.topic} [${miss.importance}]`, 18, y + 4);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(71, 85, 105);
      doc.text(miss.summary, 18, y + 8.5);

      y += 14;
    });
  }

  y += 4;

  // Recommendations
  if (analysis.recommendations && analysis.recommendations.length > 0) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(67, 56, 202); // Indigo
    doc.text('EXPERT ACTION PLAN & REVISION STEPS', 14, y);
    y += 5;

    analysis.recommendations.slice(0, 3).forEach((rec, idx) => {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(30, 41, 59);
      doc.text(`• ${rec}`, 18, y + 4);
      y += 5.5;
    });
  }

  // Footer
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  doc.text(
    'NotesChecker AI is built for Class 11 & 12 CBSE, State Board, JEE, NEET & MHT-CET students. Verified against NCERT guidelines.',
    pageWidth / 2,
    290,
    { align: 'center' }
  );

  doc.save(`NotesChecker_${analysis.subject}_${analysis.classLevel.replace(' ', '')}_Score_${analysis.overallScore}.pdf`);
}
