/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CriteriaScore, ExamTarget } from '../types';

export interface RawCriteriaScores {
  contentAccuracy: number; // 0 - 100
  topicCoverage: number;   // 0 - 100
  conceptClarity: number;  // 0 - 100
  organization: number;    // 0 - 100
  examRelevance: number;   // 0 - 100
}

export const CRITERIA_WEIGHTS = {
  contentAccuracy: 30, // 30%
  topicCoverage: 25,   // 25%
  conceptClarity: 15,  // 15%
  organization: 10,    // 10%
  examRelevance: 20,   // 20%
} as const;

/**
 * Calculates overall weighted score out of 100 strictly following prompt criteria:
 * Content Accuracy: 30%
 * Topic Coverage: 25%
 * Concept Clarity: 15%
 * Organization: 10%
 * Exam Relevance: 20%
 */
export function calculateWeightedScore(raw: RawCriteriaScores): {
  overallScore: number;
  criteria: {
    contentAccuracy: CriteriaScore;
    topicCoverage: CriteriaScore;
    conceptClarity: CriteriaScore;
    organization: CriteriaScore;
    examRelevance: CriteriaScore;
  };
} {
  const clamp = (val: number) => Math.max(0, Math.min(100, Math.round(val)));

  const accScore = clamp(raw.contentAccuracy);
  const covScore = clamp(raw.topicCoverage);
  const claScore = clamp(raw.conceptClarity);
  const orgScore = clamp(raw.organization);
  const relScore = clamp(raw.examRelevance);

  const accWeighted = Number(((accScore * CRITERIA_WEIGHTS.contentAccuracy) / 100).toFixed(1));
  const covWeighted = Number(((covScore * CRITERIA_WEIGHTS.topicCoverage) / 100).toFixed(1));
  const claWeighted = Number(((claScore * CRITERIA_WEIGHTS.conceptClarity) / 100).toFixed(1));
  const orgWeighted = Number(((orgScore * CRITERIA_WEIGHTS.organization) / 100).toFixed(1));
  const relWeighted = Number(((relScore * CRITERIA_WEIGHTS.examRelevance) / 100).toFixed(1));

  const total = Math.round(accWeighted + covWeighted + claWeighted + orgWeighted + relWeighted);
  const overallScore = Math.max(0, Math.min(100, total));

  return {
    overallScore,
    criteria: {
      contentAccuracy: {
        name: 'Content Accuracy',
        weight: CRITERIA_WEIGHTS.contentAccuracy,
        score: accScore,
        weightedScore: accWeighted,
        feedback: getAccuracyFeedback(accScore),
      },
      topicCoverage: {
        name: 'Topic Coverage',
        weight: CRITERIA_WEIGHTS.topicCoverage,
        score: covScore,
        weightedScore: covWeighted,
        feedback: getCoverageFeedback(covScore),
      },
      conceptClarity: {
        name: 'Concept Clarity',
        weight: CRITERIA_WEIGHTS.conceptClarity,
        score: claScore,
        weightedScore: claWeighted,
        feedback: getClarityFeedback(claScore),
      },
      organization: {
        name: 'Organization',
        weight: CRITERIA_WEIGHTS.organization,
        score: orgScore,
        weightedScore: orgWeighted,
        feedback: getOrganizationFeedback(orgScore),
      },
      examRelevance: {
        name: 'Exam Relevance',
        weight: CRITERIA_WEIGHTS.examRelevance,
        score: relScore,
        weightedScore: relWeighted,
        feedback: getRelevanceFeedback(relScore),
      },
    },
  };
}

export function calculateGrade(score: number): 'A+' | 'A' | 'B+' | 'B' | 'C' | 'Needs Improvement' {
  if (score >= 90) return 'A+';
  if (score >= 80) return 'A';
  if (score >= 70) return 'B+';
  if (score >= 60) return 'B';
  if (score >= 50) return 'C';
  return 'Needs Improvement';
}

export function calculateExamReadiness(score: number, examTarget: ExamTarget): number {
  // Competitive exams (JEE Main, NEET) have stricter requirements for readiness
  let multiplier = 1.0;
  if (examTarget === 'JEE Main' || examTarget === 'NEET') {
    multiplier = 0.92;
  } else if (examTarget === 'MHT-CET') {
    multiplier = 0.95;
  }
  return Math.max(10, Math.min(100, Math.round(score * multiplier)));
}

function getAccuracyFeedback(score: number): string {
  if (score >= 85) return 'Definitions and scientific statements are factually sound.';
  if (score >= 70) return 'Minor inaccuracies in signs or boundary conditions identified.';
  return 'Several conceptual misstatements or incorrect formulas detected.';
}

function getCoverageFeedback(score: number): string {
  if (score >= 85) return 'Covers nearly all core NCERT syllabus subtopics.';
  if (score >= 70) return 'Good fundamental coverage, but misses 2-3 key exam subtopics.';
  return 'Major syllabus gaps found. Essential derivations or cases omitted.';
}

function getClarityFeedback(score: number): string {
  if (score >= 85) return 'Crystal clear explanations, lucid definitions and step explanations.';
  if (score >= 70) return 'Adequate conceptual explanations; could use clearer variable definitions.';
  return 'Ambiguous explanations, shorthand missing crucial conditions.';
}

function getOrganizationFeedback(score: number): string {
  if (score >= 85) return 'Well-structured headings, bullet points, and highlighted formulas.';
  if (score >= 70) return 'Reasonable flow, but derivations blend into descriptions.';
  return 'Disorganized flow; difficult to distinguish laws from examples.';
}

function getRelevanceFeedback(score: number): string {
  if (score >= 85) return 'Strong alignment with high-yield previous year questions (PYQs).';
  if (score >= 70) return 'Relevant to basic syllabus, but lacks high-weightage shortcuts.';
  return 'Lacks focus on recurring exam questions and standard derivations.';
}
