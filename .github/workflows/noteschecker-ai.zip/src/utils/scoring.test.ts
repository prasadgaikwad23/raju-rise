/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateWeightedScore,
  calculateGrade,
  calculateExamReadiness,
  CRITERIA_WEIGHTS,
} from './scoring';

test('criteria weights sum exactly to 100%', () => {
  const sum =
    CRITERIA_WEIGHTS.contentAccuracy +
    CRITERIA_WEIGHTS.topicCoverage +
    CRITERIA_WEIGHTS.conceptClarity +
    CRITERIA_WEIGHTS.organization +
    CRITERIA_WEIGHTS.examRelevance;
  assert.equal(sum, 100);
  assert.equal(CRITERIA_WEIGHTS.contentAccuracy, 30);
  assert.equal(CRITERIA_WEIGHTS.topicCoverage, 25);
  assert.equal(CRITERIA_WEIGHTS.conceptClarity, 15);
  assert.equal(CRITERIA_WEIGHTS.organization, 10);
  assert.equal(CRITERIA_WEIGHTS.examRelevance, 20);
});

test('calculateWeightedScore computes accurate weighted sum with 100s', () => {
  const result = calculateWeightedScore({
    contentAccuracy: 100,
    topicCoverage: 100,
    conceptClarity: 100,
    organization: 100,
    examRelevance: 100,
  });
  assert.equal(result.overallScore, 100);
  assert.equal(result.criteria.contentAccuracy.weightedScore, 30);
  assert.equal(result.criteria.topicCoverage.weightedScore, 25);
  assert.equal(result.criteria.conceptClarity.weightedScore, 15);
  assert.equal(result.criteria.organization.weightedScore, 10);
  assert.equal(result.criteria.examRelevance.weightedScore, 20);
});

test('calculateWeightedScore computes accurate weighted sum with realistic values', () => {
  // Accuracy: 80 * 0.30 = 24.0
  // Coverage: 60 * 0.25 = 15.0
  // Clarity: 70 * 0.15 = 10.5
  // Org: 90 * 0.10 = 9.0
  // Relevance: 85 * 0.20 = 17.0
  // Sum = 24 + 15 + 10.5 + 9 + 17 = 75.5 -> round to 76
  const result = calculateWeightedScore({
    contentAccuracy: 80,
    topicCoverage: 60,
    conceptClarity: 70,
    organization: 90,
    examRelevance: 85,
  });
  assert.equal(result.overallScore, 76);
  assert.equal(result.criteria.contentAccuracy.score, 80);
});

test('calculateGrade assigns correct grade bands', () => {
  assert.equal(calculateGrade(95), 'A+');
  assert.equal(calculateGrade(90), 'A+');
  assert.equal(calculateGrade(89), 'A');
  assert.equal(calculateGrade(80), 'A');
  assert.equal(calculateGrade(75), 'B+');
  assert.equal(calculateGrade(65), 'B');
  assert.equal(calculateGrade(55), 'C');
  assert.equal(calculateGrade(40), 'Needs Improvement');
});

test('calculateExamReadiness scales properly by exam target', () => {
  const jee = calculateExamReadiness(80, 'JEE Main');
  const school = calculateExamReadiness(80, 'School Examination');
  assert.ok(jee <= school);
  assert.equal(school, 80);
  assert.equal(jee, 74); // 80 * 0.92 = 73.6 -> 74
});
