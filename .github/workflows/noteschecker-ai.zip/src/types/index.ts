/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ClassLevel = 'Class 11' | 'Class 12';

export type EducationBoard = 'CBSE' | 'State Board (Maharashtra)' | 'ICSE / ISC' | 'Other State Board';

export type Subject =
  | 'Physics'
  | 'Chemistry'
  | 'Mathematics'
  | 'Biology'
  | 'English'
  | 'Computer Science';

export type ExamTarget =
  | 'School Examination'
  | 'JEE Main'
  | 'NEET'
  | 'MHT-CET'
  | 'General Learning';

export interface CriteriaScore {
  name: string;
  weight: number; // percentage, e.g. 30
  score: number; // 0-100
  weightedScore: number; // score * (weight / 100)
  feedback: string;
}

export interface DetectedError {
  topic: string;
  studentText: string;
  issue: string;
  correction: string;
  severity: 'high' | 'medium' | 'low';
}

export interface MissingConcept {
  topic: string;
  importance: 'Critical for Exam' | 'High Weightage' | 'Fundamental';
  examRelevance: string;
  syllabusReference: string;
  summary: string;
}

export interface FormulaReference {
  name: string;
  formula: string;
  whereUsed: string;
  notesStatus: 'correct' | 'missing' | 'inaccurate';
}

export interface AnalysisResult {
  id: string;
  noteId: string;
  title: string;
  subject: Subject;
  classLevel: ClassLevel;
  board: EducationBoard;
  examTarget: ExamTarget;
  createdAt: string;
  overallScore: number; // 0 - 100
  grade: 'A+' | 'A' | 'B+' | 'B' | 'C' | 'Needs Improvement';
  examReadinessPercentage: number;
  criteria: {
    contentAccuracy: CriteriaScore;
    topicCoverage: CriteriaScore;
    conceptClarity: CriteriaScore;
    organization: CriteriaScore;
    examRelevance: CriteriaScore;
  };
  ocrExtractedText: string;
  correctConcepts: string[];
  detectedErrors: DetectedError[];
  missingConcepts: MissingConcept[];
  importantFormulas: FormulaReference[];
  recommendations: string[];
  keyTopicsIdentified: string[];
  summary: string;
}

export interface UploadedNote {
  id: string;
  userId: string;
  title: string;
  subject: Subject;
  classLevel: ClassLevel;
  board: EducationBoard;
  examTarget: ExamTarget;
  pageCount: number;
  fileNames: string[];
  filePreviews: string[]; // data URLs or image preview paths
  uploadedAt: string;
  analysis?: AnalysisResult;
  status: 'analyzed' | 'pending' | 'failed';
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  targetExam: ExamTarget;
  classLevel: ClassLevel;
  board: EducationBoard;
  institution?: string;
  joinedAt: string;
}

export interface SubjectPerformance {
  subject: Subject;
  averageScore: number;
  notesCount: number;
  lastScore: number;
  accuracyAvg: number;
  coverageAvg: number;
}
