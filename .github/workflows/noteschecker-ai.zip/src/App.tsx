/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { LandingPage } from './components/LandingPage';
import { DashboardView } from './components/DashboardView';
import { AnalyzeWizard } from './components/AnalyzeWizard';
import { AnalysisResultsView } from './components/AnalysisResultsView';
import { MyNotesView } from './components/MyNotesView';
import { PerformanceView } from './components/PerformanceView';
import { SettingsView } from './components/SettingsView';
import { HelpSupportView } from './components/HelpSupportView';
import { AuthModal } from './components/AuthModal';

const AppContent: React.FC = () => {
  const { user, activeView, setActiveView } = useApp();
  const [isMobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Support ?autostart=1 or ?view=... query param as specified in ultra-mode instructions
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const viewParam = params.get('view');
    const autoStart = params.get('autostart');

    if (viewParam) {
      setActiveView(viewParam);
    } else if (autoStart === '1') {
      setActiveView('dashboard');
    }
  }, [setActiveView]);

  const isLandingView = !user || activeView === 'landing';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors selection:bg-purple-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar onOpenMobileSidebar={() => setMobileSidebarOpen(true)} />

      {/* Main Layout */}
      {isLandingView ? (
        <main className="flex-1">
          <LandingPage />
        </main>
      ) : (
        <div className="flex-1 flex max-w-7xl w-full mx-auto">
          {/* Responsive Sidebar with 8 requested items */}
          <Sidebar
            isMobileOpen={isMobileSidebarOpen}
            onCloseMobile={() => setMobileSidebarOpen(false)}
          />

          {/* Active View Container */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0 overflow-y-auto">
            {activeView === 'dashboard' && <DashboardView />}
            {activeView === 'analyze' && <AnalyzeWizard />}
            {activeView === 'results' && <AnalysisResultsView />}
            {activeView === 'notes' && <MyNotesView />}
            {activeView === 'history' && <MyNotesView />}
            {activeView === 'performance' && <PerformanceView />}
            {activeView === 'settings' && <SettingsView />}
            {activeView === 'help' && <HelpSupportView />}
          </main>
        </div>
      )}

      {/* Global Authentication Modal */}
      <AuthModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
